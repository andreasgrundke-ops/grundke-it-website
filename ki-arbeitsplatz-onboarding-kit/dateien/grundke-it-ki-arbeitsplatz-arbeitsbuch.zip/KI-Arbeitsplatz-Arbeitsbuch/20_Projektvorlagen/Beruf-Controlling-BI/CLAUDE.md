# CLAUDE.md — [Themenname]

> Beispielhaft ausgefüllt für ein Kennzahlen-Projekt. Alles in eckigen Klammern ersetzen,
> alles Übrige prüfen und anpassen. Diese Datei gehört in den Themenordner **und** als
> Projektwissen in das Claude-Projekt.

## Ziel
[Ein Satz. Beispiel: Ein Kennzahlenmodell für den Vertriebsbericht, das monatlich ohne
Handarbeit aktualisiert wird und für drei Nutzergruppen unterschiedliche Sichten liefert.]

## Datenrahmen
Neutralisierte Strukturen und erfundene Daten. Keine Echtdaten, keine Personenbezüge.
Die Zuordnung zwischen neutralisierten und echten Bezeichnungen liegt ausschließlich
offline.

## Fachlicher Hintergrund
[Zwei bis fünf Sätze für jemanden, der neu dazukommt: worum es fachlich geht, welche
Kennzahlen im Mittelpunkt stehen, welche Besonderheiten es gibt.]

## Technik
- Quelle: [z. B. MS SQL Server, Schema `stage`, historisiert]
- Modell: [z. B. Stern-Schema, Faktentabelle `F_Umsatz`, Dimensionen `D_Zeit`,
  `D_Produkt`, `D_Vertrieb`, `D_Region`]
- Berichte: [z. B. Power BI, semantisches Modell im Import-Modus]
- Ablage: `sql/` `dax/` `doku/` `testdaten/` `ergebnisse/`

## Namenskonventionen
- Faktentabellen `F_*`, Dimensionen `D_*`, Sichten `V_*`, Prozeduren `proc_*`
- Kennzahlen: `[Bereich] [Kennzahl] [Variante]` — z. B. `Vertrieb Umsatz VJ`
- Sicherheitsrollen: `RLS_<Dimension>_<Kriterium>`
- Dateien: `<bereich>-<thema>-<objekt>`

## Regeln in diesem Projekt
- Kennzahlen bekommen erst eine Definition, dann eine Formel.
- Jede Kennzahl wird im Glossar dokumentiert, sobald sie steht.
- Änderungen an bestehenden Skripten: Version hochzählen, Änderungshistorie ergänzen.
- Vorschläge für die Produktivumgebung gelten als Entwurf — Prüfung erfolgt auf einer
  Testumgebung.
- Berechtigungslogik wird nie nebenbei geändert, sondern als eigener Baustein behandelt.

## Bausteine
| Kürzel | Baustein | Fertig, wenn | Status |
|---|---|---|---|
| B1 | Datenmodell entworfen | Stern-Schema steht, Beziehungen dokumentiert | offen |
| B2 | Testdatengenerator | Skript läuft reproduzierbar, Plausibilitätsprüfungen grün | offen |
| B3 | Basiskennzahlen | 10 Kennzahlen definiert, gebaut, dokumentiert | offen |
| B4 | Berechtigungskonzept | Rollenmatrix steht, Testfälle je Rolle beschrieben | offen |
| B5 | Berichtslayout | Layout nach Design-System, drei Nutzergruppen abgebildet | offen |

## Stand
- Zuletzt: [Datum] — [was]
- Offen: [Entscheidungen, die noch anstehen]
- Nächster Schritt: [eine Zeile, konkret]

## Bekannte Fallstricke
- [Hier gehören die Dinge hin, die schon einmal schiefgegangen sind. Dieser Abschnitt
  ist am Anfang leer und wird mit der Zeit der wertvollste der ganzen Datei.]

## Verweise
STATUS.md · BACKLOG.md · doku/glossar.md · 99_Vorlagen/design-system/

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.0*
