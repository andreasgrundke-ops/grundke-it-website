# CLAUDE.md — Privat / [Themenname]

> Bewusst schlank. Privat braucht weniger Struktur als Beruf — aber ein Minimum lohnt sich auch hier,
> sonst fängt jede Sitzung mit Erklären an.

## Worum es geht
[Ein Satz.]

## Rahmenbedingungen
[Was jedes Mal gilt und was man nicht wiederholen möchte: Haushaltsgröße, Fahrzeuge, Wohnsituation,
laufende Verträge, wiederkehrende Termine — soweit für dieses Thema relevant.]

## Wie ich Ergebnisse haben will
- [z. B. Entscheidungen mit Vor- und Nachteilen, dann eine Empfehlung]
- [z. B. Einkaufs- und Aufgabenlisten als abhakbare Liste]
- [z. B. längere Ausarbeitungen als Datei]

## Stand
- Zuletzt: [Datum] — [was]
- Offen: [was noch entschieden werden muss]
- Nächster Schritt: [eine Zeile]

## Ablage
`daten/` — Unterlagen · `ergebnisse/` — Fertiges

## Grenzen
Zugangsdaten, Kontonummern und Ausweisdaten gehören in den Passwortmanager, nicht hierher —
auch nicht privat.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
