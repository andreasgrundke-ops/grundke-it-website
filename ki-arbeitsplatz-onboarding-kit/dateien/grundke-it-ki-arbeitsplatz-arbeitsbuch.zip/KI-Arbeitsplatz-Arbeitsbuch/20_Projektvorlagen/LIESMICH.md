# Projektvorlagen

Zwei fertige Projekte zum Übernehmen. Beide bestehen aus einer **Projektanweisung** (kommt in Claude in
das Projekt) und einer **CLAUDE.md** (kommt in den Ordner auf dem Rechner und zusätzlich als
Projektwissen ins Projekt).

| Ordner | Für |
|---|---|
| `Privat/` | Alles Private — bewusst schlank gehalten |
| `Beruf-Controlling-BI/` | Fachliche Arbeit mit Datenmodellen, Kennzahlen und Berichten |

## Ordnerstruktur zum Anlegen

```
KI-Arbeit/
  00_Wurzel/
    CLAUDE.md
    LANDKARTE.md
  01_Privat/
    <thema>/
      CLAUDE.md
      STATUS.md
      daten/
      ergebnisse/
  02_Beruf/
    <thema>/
      CLAUDE.md
      STATUS.md
      BACKLOG.md
      sql/
      dax/
      doku/
      testdaten/
      ergebnisse/
  99_Vorlagen/
    muster-md/
    skills/
    design-system/
```

Anlegen lässt sich das in einem Rutsch: Ordner `KI-Arbeit` erstellen, in der Desktop-App freigeben,
dann Claude bitten, die Struktur nach dieser Vorlage anzulegen und die Muster-MDs an die richtigen
Stellen zu kopieren.

## LANDKARTE.md

Eine Datei im Wurzelordner, die alle Themen auflistet:

```markdown
# Landkarte

| Thema | Ordner | Claude-Projekt | Status | Zuletzt |
|---|---|---|---|---|
| Vertriebskennzahlen | 02_Beruf/vertriebskennzahlen | Beruf – Controlling | in Arbeit | 2026-08-29 |
| Berechtigungskonzept | 02_Beruf/berechtigungen | Beruf – Controlling | offen | — |
| Umzug | 01_Privat/umzug | Privat | ruht | 2026-07-14 |
```

Zwei Minuten Pflege je Thema — dafür jederzeit die Antwort auf die Frage, was eigentlich alles offen ist.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
