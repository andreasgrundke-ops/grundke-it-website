# 02 · Installation — macOS und Windows

## Was installiert wird und warum

| Teil | Wozu | Pflicht? |
|---|---|---|
| Desktop-App | Zentrale. Einziger Weg zu **lokalen Dateien** und zum Browser | ja |
| Claude Code (Kommandozeile) | Arbeiten in Ordnern und Dateien, SQL, Skripte | ja, wenn Code eine Rolle spielt |
| VS Code + Erweiterung | Bequeme Oberfläche für dasselbe | empfohlen |
| Browsererweiterung (Chrome) | Claude bedient Webseiten | empfohlen |
| Office-Erweiterungen | Claude arbeitet in Excel, PowerPoint, Word | optional, für Controlling sehr nützlich |
| Telefon-App | Diktieren, nachlesen, unterwegs | empfohlen |

## Desktop-App

**Voraussetzung:** macOS 11 oder neuer. Windows-Version verfügbar, einschließlich ARM.
**Achtung:** Claude Code verlangt macOS 13 oder neuer — auf älteren Geräten endet der Plan bei Phase 7.

1. **claude.com/download** öffnen
2. macOS: DMG öffnen, Claude in „Programme" ziehen, **aus dem Programme-Ordner** starten
   (nicht aus dem geöffneten Datenträger — sonst meckert das System bei jedem Start)
3. Anmelden, App im Dock verankern

### Ordnerfreigabe verstehen

Cowork-Sitzungen laufen auf Servern des Anbieters. Damit Claude an lokale Dateien kommt, muss die
Desktop-App **geöffnet** sein und ein Ordner ausdrücklich freigegeben werden.

Eine Freigabe bedeutet **lesen und schreiben**. Deshalb:

- einen **Arbeitsordner** freigeben, nie das Benutzerverzeichnis
- der freigegebene Ordner sollte in einer Sicherung liegen
- vor größeren Umbauten in fremden Dateien: Kopie ziehen

## Claude Code

**Voraussetzungen:** macOS 13+ (oder Windows/Linux), 4 GB RAM, Terminal. **Node.js ist nicht nötig.**

Empfohlener Weg — Terminal öffnen:

```bash
curl -fsSL https://claude.ai/install.sh | bash
```

Alternativ über Homebrew (dann ohne automatische Updates):

```bash
brew install --cask claude-code
```

Prüfen:

```bash
claude --version
claude doctor
```

### Anmelden mit Abo statt Schlüssel

In einen Projektordner wechseln und `claude` starten. Es öffnet sich der Browser-Login; ein
API-Schlüssel wird **nicht** gebraucht.

> **Häufige Falle:** Ist in der Shell die Variable `ANTHROPIC_API_KEY` gesetzt (etwa aus einem früheren
> Versuch), will Claude Code diese benutzen und rechnet nach Verbrauch ab statt über das Abo. Vorher
> entfernen und die Shell neu starten.

Update später: `claude update`.

## VS Code

1. **code.visualstudio.com** — Version 1.94 oder neuer
2. Erweiterungen öffnen (`Cmd+Shift+X`), nach **Claude Code** suchen, Herausgeber **Anthropic**,
   installieren
3. Fenster neu laden

Was die Erweiterung bringt: ein Panel direkt in der Entwicklungsumgebung, Pläne als lesbares Dokument
vor der Freigabe, Änderungen als Vorher-Nachher zum Annehmen oder Ablehnen, Dateien per `@` in die
Unterhaltung ziehen, mehrere Sitzungen nebeneinander.

> **Wichtig:** Erweiterung und Kommandozeile sind **zwei getrennte Installationen**. Die Erweiterung
> allein gibt kein `claude` im Terminal.

## Browsererweiterung

Nur **Google Chrome** — keine anderen Chromium-Browser, kein Safari, kein Mobilgerät. Bezahlter Plan
erforderlich.

1. Chrome Web Store → Claude-Erweiterung → hinzufügen
2. Anmelden, Erweiterung anheften
3. Berechtigungen **pro Website** vergeben, nicht pauschal

Damit kann Claude Seiten lesen, klicken, Formulare ausfüllen, Bildschirmfotos machen, mehrere Tabs
steuern und wiederkehrende Abläufe aufzeichnen.

> **Bewusst einsetzen.** Ein Agent im angemeldeten Browser handelt mit den Rechten des angemeldeten
> Menschen. Auf Firmenanwendungen gehört das nur nach ausdrücklicher Freigabe.

## Office-Erweiterungen

Add-ins aus **Microsoft AppSource** für Excel, PowerPoint und Word (Outlook als Vorabversion), für
bezahlte Pläne auf Mac und Windows. Claude arbeitet dann in der geöffneten Datei mit.

Auf einem verwalteten Firmenrechner entscheidet das Admin Center darüber, ob sich Add-ins installieren
lassen — dort also nicht am Widerstand des Rechners verzweifeln, sondern beantragen.

## Reihenfolge

1. Desktop-App, anmelden
2. Grundeinstellungen (Anleitung 03) — **vor** allem anderen
3. VS Code, dann Claude Code, dann Erweiterung
4. Browsererweiterung
5. Office-Erweiterungen, Telefon-App

Grundeinstellungen vor Werkzeugen: Wer erst Werkzeuge installiert und dann erklärt, wer er ist,
verschenkt jede Sitzung dazwischen.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
