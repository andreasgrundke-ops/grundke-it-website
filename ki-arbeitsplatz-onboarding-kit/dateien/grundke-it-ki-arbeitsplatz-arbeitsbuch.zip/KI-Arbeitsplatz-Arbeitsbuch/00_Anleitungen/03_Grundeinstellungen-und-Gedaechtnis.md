# 03 · Grundeinstellungen und Gedächtnis

Der Schritt mit dem besten Verhältnis von Aufwand zu Wirkung. Fünfzehn Minuten hier verändern jede
Antwort danach.

## Die drei Ebenen der Personalisierung

Sie stapeln sich — alle drei wirken gleichzeitig:

| Ebene | Wo | Gilt für | Inhalt |
|---|---|---|---|
| **Kontoweit** | Einstellungen → Instructions for Claude | jeden Chat, auch mobil | Wer ich bin, wie ich Antworten will, welche Daten tabu sind |
| **Projekt** | Projekt → Projektanweisungen | alle Chats dieses Projekts | Fachlicher Rahmen, Datenlage, Projektregeln |
| **Skill** | Customize → Skills | wenn das Thema vorkommt | Handwerkliche Regeln für eine Art von Aufgabe |

Faustregel: Was für **alles** gilt, kommt nach oben. Was nur für **ein Thema** gilt, ins Projekt. Was nur
für **eine Art Aufgabe** gilt, in ein Skill. Wer alles nach oben schreibt, bekommt eine überladene
Anweisung, die niemand mehr pflegt.

## Kontoweite Anweisungen setzen

Initialen unten links → Einstellungen → **Instructions for Claude**.

Fertige Vorlage: `10_Muster-MD/00_Persoenliche-Anweisungen.md` — ausfüllen, kopieren, einfügen.

**Danach die Gegenprobe:** neuen Chat öffnen und fragen

> Fasse in fünf Zeilen zusammen, wer ich bin, wie ich Antworten haben will und welche Daten tabu sind.

Stimmt die Antwort nicht, ist die Anweisung zu vage. Nachschärfen — zwei Minuten, wirkt danach täglich.

## Das Gedächtnis

Claude bringt ein **eingebautes, dauerhaftes Gedächtnis** über Chats hinweg mit. Bei Einzelplänen ist es
standardmäßig eingeschaltet, bei Firmenplänen muss es freigegeben werden.

**Einstellungen → Memory.** Dort lässt sich alles einsehen, einzeln bearbeiten, löschen, pausieren oder
vollständig zurücksetzen.

### Was hineingehört

Rolle, Fachgebiet, laufende Vorhaben, Arbeits- und Kommunikationsvorlieben. Also: das, was man einem
neuen Kollegen in der ersten Woche erzählt.

### Was nicht hineingehört

- Zugangsdaten, Schlüssel, Kontonummern — niemals
- Personenbezogene Daten Dritter aus dem Arbeitskontext
- Gesundheit, Religion, Politik, Persönliches. Solche Kategorien sind standardmäßig ausgeschlossen —
  das sollte so bleiben.

### Gedächtnis oder Projektunterlagen?

Eine Frage, die oft falsch beantwortet wird:

- **Gedächtnis** = Fakten über **die Person**. Folgt ihr überallhin, auch in private Unterhaltungen.
- **CLAUDE.md und Projektwissen** = Fakten über **das Vorhaben**. Bleiben, wo sie hingehören.

„Ich bin Controllerin und arbeite mit Power BI" gehört ins Gedächtnis. „In diesem Datenmodell heißt die
Faktentabelle F_Vertrag" gehört in die CLAUDE.md. Wer beides vermischt, hat später ein Gedächtnis voller
Projektdetails, die längst nicht mehr stimmen.

### Ein eigenes „Gehirn" bauen?

Nicht nötig. Das eingebaute Gedächtnis deckt den Zweck ab. Selbstgebaute Wissensspeicher (etwa über
einen eigenen Dienst) haben ihre Berechtigung, wenn man den Speicherort selbst kontrollieren will oder
mehrere Werkzeuge auf dieselbe Wissensbasis zugreifen sollen — aber sie sind ein Ausbauschritt, kein
Einstieg. Wer damit anfängt, betreibt Infrastruktur statt zu arbeiten.

Wichtig, falls das später doch kommt: Wer für jemand anderen einen solchen Dienst betreibt, verarbeitet
dessen Daten — mit allem, was daran hängt. Das ist eine bewusste Entscheidung, kein Nebeneffekt.

## Code-Ausführung aktivieren

**Einstellungen → Capabilities → Code Execution.**

Ohne diesen Schalter:

- bleiben **Skills unsichtbar**
- lassen sich **keine Dateien erzeugen** (Excel, Word, PowerPoint, PDF)
- funktionieren Auswertungen und Diagramme nicht

Das ist die häufigste Ursache für „bei mir sieht das ganz anders aus als in der Anleitung".

## Weitere Einstellungen, die sich lohnen

| Einstellung | Empfehlung |
|---|---|
| Sprache der Oberfläche | Deutsch, wenn gewünscht — die Antwortsprache steuert ohnehin die Anweisung |
| Erscheinungsbild | Geschmackssache; hell für Präsentationen, dunkel für lange Sitzungen |
| Chat-Suche | eingeschaltet lassen — findet Gesprächenoch nach Wochen wieder |
| Inkognito | kennen, für Themen, die nirgends auftauchen sollen |

## Prüfliste

- [ ] Kontoweite Anweisungen gesetzt und gegengeprüft
- [ ] Gedächtnis angesehen, verstanden, ggf. bereinigt
- [ ] Code-Ausführung eingeschaltet
- [ ] Trainingsfreigabe aus (siehe Anleitung 01)
- [ ] Zwei-Faktor-Anmeldung aktiv

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
