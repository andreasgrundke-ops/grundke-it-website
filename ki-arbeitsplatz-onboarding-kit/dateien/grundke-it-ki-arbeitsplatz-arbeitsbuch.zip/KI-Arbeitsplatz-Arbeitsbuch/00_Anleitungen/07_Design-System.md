# 07 · Design-System früh festlegen

## Warum das ganz am Anfang steht

Jedes Dashboard, jede Auswertung, jede Präsentation und jedes Dokument, das ab jetzt entsteht, erbt eine
Optik. Wird sie erst nach zwanzig Ergebnissen festgelegt, müssen zwanzig Ergebnisse nachgearbeitet
werden. Und im Berichtswesen ist Einheitlichkeit kein Schönheitsthema: Wer Ist-Werte mal blau und mal
grau darstellt, produziert Rückfragen statt Erkenntnis.

## Wo

**claude.ai/design** oder über die Seitenleiste der Desktop-App. Links Chat, rechts eine Zeichenfläche.
Man beschreibt, was entstehen soll, und verfeinert danach — im Gespräch, per Kommentar oder direkt auf
der Fläche.

Ergebnisse lassen sich als HTML, PDF, Präsentation oder Paket exportieren und an Claude Code übergeben.

## Der Fragenkatalog

Diese Liste in einem Design-Chat abarbeiten. Am schnellsten geht es, wenn man Claude bittet, sie der
Reihe nach abzufragen.

### Farben

1. Primärfarbe — die eine Farbe, die überall auftaucht
2. Akzentfarbe — für Hervorhebungen, sparsam
3. Statusfarben: gut / Warnung / kritisch / neutral
4. Hintergrund hell und dunkel, Textfarbe, Trennlinienfarbe
5. **Gibt es eine Hausvorgabe?** Dann wird sie abgebildet, nicht neu erfunden.

### Schrift

6. Schriftfamilie für Fließtext und Überschriften
7. Schriftfamilie für Zahlen und Code — **eine Schrift mit gleicher Zeichenbreite**, damit Zahlenkolonnen
   untereinander stehen
8. Größenstufen: Überschrift, Zwischenüberschrift, Fließtext, Kleintext

### Aufbau

9. Abstandsraster (etwa Vielfache von 4 oder 8 Pixeln)
10. Eckenrundung, Rahmen oder Schatten
11. Maximale Textbreite

### Und jetzt der Teil, an dem Berichte tatsächlich scheitern

12. **Ist gegen Plan** — welche Farbe hat welche Größe? Konsequent, überall gleich.
13. **Vorzeichenlogik** — ist ein Minus rot oder grün? Bei Kosten ist ein Minus gut, beim Umsatz
    schlecht. Die Regel muss **einmal** festgelegt und dann überall gleich angewendet werden.
14. **Tausendertrennung und Nachkommastellen** je Kennzahlenart: Beträge, Stückzahlen, Quoten, Faktoren
15. **Währungsdarstellung** — Symbol vor oder nach der Zahl, Tsd./Mio. abkürzen ab wann
16. **Umgang mit fehlenden Werten** — leer, Strich oder Null? Das ist keine Formatfrage, sondern eine
    fachliche Aussage
17. **Diagrammtypen**: Wofür Balken, wofür Linien, wofür gar kein Diagramm. Und: keine Torten für mehr
    als drei Werte
18. **Sortierung** in Tabellen: nach Größe oder nach Fachlogik, absteigend oder aufsteigend

### Barrierefreiheit

19. Ausreichender Kontrast zwischen Text und Hintergrund
20. **Keine Information ausschließlich über Farbe.** Rot und grün nebeneinander sind für einen
    erheblichen Teil der Leserschaft nicht unterscheidbar — es braucht zusätzlich ein Zeichen, ein
    Vorzeichen oder eine Beschriftung.

## Ergebnis sichern

1. Design-System exportieren
2. In beide Projekte als Projektwissen hochladen
3. In der globalen `CLAUDE.md` darauf verweisen
4. In `99_Vorlagen/design-system/` ablegen

Erst danach greift es automatisch. Ein Design-System, das nur in einer Unterhaltung existiert, ist keins.

## Zwei Systeme statt eines

Privat darf anders aussehen als dienstlich. Zwei klare Systeme sind besser als eines, das beides halb
kann.

## Was ein Design-System nicht ist

Es ersetzt keine Corporate Identity und keine Freigabe durch die Kommunikationsabteilung. Für interne
Arbeitsergebnisse reicht es vollkommen; alles, was das Haus verlässt, geht den üblichen Weg.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
