# 05 · Skills und Konnektoren

## Skills

### Was das ist

Ein Skill ist ein Ordner mit einer `SKILL.md` und optionalen Hilfsdateien. Er beschreibt, wie eine
bestimmte Art von Aufgabe zu erledigen ist. Claude lädt ihn nur, wenn das Thema tatsächlich vorkommt —
er kostet also nichts, solange er nicht gebraucht wird.

Der Kern in einem Satz: **Fachwissen einmal formulieren, danach wirkt es automatisch bei jeder passenden
Anfrage.** Das ist der Unterschied zwischen jemandem, der Claude benutzt, und jemandem, der sich einen
Arbeitsplatz gebaut hat.

### Voraussetzung

**Code-Ausführung muss eingeschaltet sein** (Einstellungen → Capabilities). Ohne diesen Schalter tauchen
Skills gar nicht erst auf.

### Grundausstattung einschalten

Seitenleiste → **Customize** → Reiter **Skills**. Einschalten:

| Skill | Wofür |
|---|---|
| Tabellen (xlsx) | Excel-Dateien lesen, bauen, korrigieren, Formeln setzen |
| Textdokumente (docx) | Word-Dokumente mit Formatierung, Verzeichnissen, Kopfzeilen |
| Präsentationen (pptx) | Foliensätze erzeugen und bearbeiten |
| PDF | lesen, zusammenführen, aufteilen, erzeugen |

Für Controlling ist der Tabellen-Skill der wichtigste — er ist der Unterschied zwischen „hier ist eine
Tabelle als Text" und „hier ist deine fertige Arbeitsmappe".

### Verzeichnis

**Customize → Skills → „+" → Browse skills.** Dort liegen Skills, Konnektoren und Plugins gemeinsam.

Nur installieren, was man versteht. Ein Skill ist ausführbarer Text aus fremder Hand und gehört wie
jede andere Software geprüft: Wer hat ihn geschrieben, was macht er, welche Verbindungen baut er auf.

### Eigene Skills hochladen

Skill-Ordner als **ZIP** packen → **Customize → Skills → „+" → Upload a skill**.

Aus dem Verzeichnis installierte Skills lassen sich nicht ändern. Wer sie anpassen will, lädt sie
herunter und stellt eine eigene Fassung ein.

### Die Skills in diesem Kit

Alle unter `30_Skills/`, jeder als eigener Ordner. Bewusst als Gerüst gehalten — sie werden erst
richtig gut, wenn die eigenen Hausregeln darin stehen.

| Skill | Zweck |
|---|---|
| `sql-hausstil` | T-SQL einheitlich schreiben, Kopfzeilen, Versionierung, Fallstricke |
| `dax-hausstil` | Kennzahlen einheitlich benennen, formatieren, kommentieren |
| `datenmodell-review` | Stern-Schema-Prüfliste, typische Modellierungsfehler |
| `berechtigungs-audit` | Rollen- und Gruppenexporte prüfen, Widersprüche finden |
| `rls-konzept` | Zeilenrechte planen, dokumentieren, testen |
| `testdaten-generator` | Skript für plausible erfundene Daten statt Echtdaten |
| `code-review` | Fremden und eigenen Code strukturiert durchgehen |
| `fehlersuche` | Fehler methodisch eingrenzen statt raten |
| `dokumentation` | Einheitliche technische Dokumentation |
| `marketing-text` | Texte für Außenwirkung, ohne Werbefloskeln |
| `seo-und-ki-suche` | Auffindbarkeit klassisch und in KI-Antworten |
| `oberflaechen-design` | Oberflächen und Dashboards gestalten |

## Konnektoren

### Grundsatz

**So viele wie nötig, so wenige wie möglich, jeder mit klarem Zweck.** Jeder Konnektor erweitert, was
Claude erreichen kann — und damit auch, was bei einem Fehler betroffen ist.

### Einrichten

**Customize → Connectors → „+"** → aus dem Verzeichnis wählen oder eigenen hinzufügen → anmelden.

### Die Empfehlung nach Reihenfolge

| Konnektor | Nutzen | Hürde |
|---|---|---|
| **Lokaler Ordner** | größter Alltagsnutzen — Dateien direkt bearbeiten | keine, nur Desktop-App |
| **Browser (Chrome)** | Recherche, Formulare, wiederkehrende Abläufe | nur Chrome, Berechtigung je Website |
| **Office-Erweiterungen** | Arbeit direkt in Excel/PowerPoint/Word | auf Firmenrechnern Admin-Sache |
| **Microsoft 365** | Outlook, SharePoint, OneDrive, Teams | **Geschäftstenant + Zustimmung eines globalen Administrators** |
| **Google-Dienste** | Gmail, Kalender, Drive | für die private Seite |
| **Bild/Video-Dienste** | Erklärvideos, Schulungsmaterial, Bilder | eigenes Guthaben, nicht über das Abo abgerechnet |
| **Fachsysteme (eigene MCP)** | Datenbank, Berichtsplattform | Freigabe, oft Vorabversionen |

### Microsoft 365 — die realistische Erwartung

Zwei harte Voraussetzungen:

1. Ein **Microsoft-Geschäftstenant.** Private Microsoft-Konten funktionieren nicht.
2. Die **ausdrückliche Zustimmung eines globalen Administrators** in Entra ID.

In einem größeren Haus ist das kein Klick, sondern ein Vorgang mit Antrag und Prüfung. Deshalb: früh
anstoßen, aber den Rest des Setups nicht davon abhängig machen.

### Datenbank und Berichtsplattform

Für Microsoft SQL Server und Power BI gibt es **keinen** fertigen Konnektor im offiziellen Verzeichnis.
Microsoft liefert eigene MCP-Server:

- einen **lokalen** zum Bearbeiten semantischer Modelle — Tabellen, Kennzahlen, Beziehungen,
  Sicherheitsrollen
- einen **entfernten** zum Abfragen von Modellen
- einen für **SQL Server** auf Basis einer Zwischenschicht, die bewusst kein freies SQL zulässt, sondern
  über definierte Entitäten mit Rechteprüfung arbeitet

Alle im Vorabversionsstadium; der entfernte braucht eine Freigabe durch die Administration der
Berichtsplattform.

**Der ehrliche Rat:** Damit nicht anfangen. Der gesamte fachliche Nutzen — Modellarbeit, Kennzahlen,
Berechtigungslogik, Dokumentation — lässt sich an **exportierten Metadaten und erfundenen Daten**
erarbeiten. Die direkte Anbindung ist ein Ausbauschritt, der Freigaben braucht, und sie ersetzt kein
einziges der vorher zu lösenden Probleme.

### Dokumentieren, was verbunden ist

`40_Konnektoren/Konnektoren-Checkliste.md` ausfüllen: was, warum, wer hat freigegeben, wann geprüft.
Das ist die Unterlage, die bei der ersten Rückfrage aus der IT gebraucht wird — und sie zu haben, bevor
gefragt wird, macht den Unterschied.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.0*
