# 11 · Lernkarten

Zum Ausdrucken, Abfragen oder Durchlesen. Frage — Antwort. Wer alle 30 beantworten kann, beherrscht die
Grundlagen.

---

## Grundlagen

**Was ist das Kontextfenster?**
Der Arbeitsspeicher einer Unterhaltung: Anweisungen, Dateien, bisheriger Verlauf. Ist er voll, geht
Frühes verloren — ohne Warnung. Deshalb: ein Thema pro Unterhaltung.

**Was kann Claude grundsätzlich nicht wissen?**
Ereignisse nach dem Wissensstand des Modells, alles Hausinterne, das nicht mitgegeben wurde, und was auf
dem eigenen Bildschirm passiert. Für Aktuelles wird gesucht; für Eigenes muss man Kontext liefern.

**Warum antwortet Claude manchmal falsch, aber überzeugend?**
Weil ein Sprachmodell plausible Fortsetzungen erzeugt. Plausibel ist nicht dasselbe wie richtig. Deshalb
gehört „nachfragen statt raten" in die Anweisungen und die fachliche Prüfung bleibt beim Menschen.

**Welches Modell wofür?**
Schnell und sparsam für Routine und Masse. Allrounder für die meiste Arbeit. Starkes Modell für
Architektur und schwierige Analysen — verbraucht deutlich mehr vom Kontingent.

**Was heißt „geteiltes Nutzungslimit"?**
Chat, Claude Code und Cowork ziehen aus demselben Topf: einem rollierenden Fenster von etwa fünf Stunden
plus einem Wochenlimit. Viel Chat am Vormittag heißt weniger Claude Code am Nachmittag.

---

## Gut prompten

**Die wichtigste Regel?**
Konkret sein. Was genau, in welchem Format, wie lang, für wen. Vage Fragen bringen vage Antworten.

**Was ist das Prompt-Grundgerüst?**
Rolle, Aufgabe, Kontext, Format. Rolle und Format gehören einmalig in die kontoweiten Anweisungen — dann
tippt man sie nie wieder.

**Was bringen Beispiele?**
Mehr als jede Erklärung. Ein gutes und ein schlechtes Beispiel des gewünschten Ergebnisses reichen meist.

**Wann „erst denken lassen"?**
Bei Analyse und Logik. „Geh erst schrittweise durch, dann gib das Ergebnis" senkt die Fehlerquote spürbar.

**Warum Material und Auftrag trennen?**
Damit klar ist, was Anweisung und was Stoff ist. Abschnitte, Überschriften oder Auszeichnungen wie
`<daten>` und `<auftrag>` genügen.

**Das Ergebnis passt nicht — was tun?**
Nachsteuern, nicht neu anfangen. Konkret sagen, was fehlt. Iterieren ist der Normalfall.

---

## Werkzeuge

**Chat, Cowork und Claude Code — was wofür?**
Chat: denken, planen, erklären. Cowork: mehrstufige Aufgaben, Dateiarbeit, Ausliefern. Claude Code:
arbeiten in Ordnern und Dateien, Skripte, SQL.

**Was macht Claude Design?**
Oberflächen, Dashboards, Foliensätze gestalten — auf einer Zeichenfläche, nicht im Code. Der Schritt
zwischen Konzept und Bauen. Ergebnisse lassen sich exportieren und an Claude Code übergeben.

**Was ist ein Projekt?**
Ein Behälter mit eigener Anweisung und eigenem Wissen. Jeder Chat darin startet im richtigen Kontext.
Achtung: Kontext wird zwischen den Chats eines Projekts nicht automatisch geteilt.

**Wozu die Browsererweiterung?**
Claude bedient Webseiten: lesen, klicken, ausfüllen, wiederkehrende Abläufe aufzeichnen. Nur Chrome.
Berechtigungen je Website vergeben — der Agent handelt mit den Rechten des angemeldeten Menschen.

**Was gehört auf das Telefon?**
Diktieren und nachlesen. Lokale Dateien erreicht nur die Desktop-App; eigene Konnektoren richtet man am
Rechner ein.

---

## Kontext und Gedächtnis

**Was macht eine CLAUDE.md?**
Sie ist das Projektgedächtnis: Ziel, Technik, Regeln, Stand, nächster Schritt. Claude Code liest sie in
jeder Sitzung. Einmal ordentlich pflegen, immer dabei.

**Die drei Ebenen von CLAUDE.md?**
Global (wer ich bin, wie ich arbeite), Projekt (was ist das Vorhaben), Baustein (ein Teil und woran man
erkennt, dass er fertig ist).

**Gedächtnis oder CLAUDE.md?**
Gedächtnis = Fakten über die Person, folgt ihr überallhin. CLAUDE.md = Fakten über das Vorhaben, bleiben
beim Vorhaben. Wer das vermischt, hat später ein Gedächtnis voller veralteter Projektdetails.

**Braucht man ein selbstgebautes Gedächtnis?**
Nein. Das eingebaute reicht. Ein eigener Wissensspeicher ist ein Ausbauschritt für Sonderfälle — und wer
ihn für andere betreibt, verarbeitet deren Daten.

**Was ist ein Skill?**
Ein Ordner mit einer `SKILL.md`. Beschreibt, wie eine Art von Aufgabe zu erledigen ist. Wird nur geladen,
wenn das Thema vorkommt. Fachwissen einmal formulieren, danach wirkt es automatisch.

**Was ist MCP?**
Ein Protokoll, über das Claude externe Dienste erreicht — Dateien, Datenbanken, Kalender, Fachsysteme.
Die Grundlage aller Konnektoren.

**Was sind Subagenten?**
Spezialisierte Helfer für Teilaufgaben, die parallel arbeiten — etwa Recherche und Prüfung gleichzeitig.
Mehr Tiefe, ohne dass man jeden Schritt selbst anstößt.

---

## Sicher arbeiten

**Die goldene Regel?**
Entwickeln und Testen nur mit erfundenen oder neutralisierten Daten. Niemals am Produktivsystem mit
Echtdaten.

**Wohin gehören Zugangsdaten?**
In den Passwortmanager oder eine Konfigurationsdatei außerhalb des Codes. Niemals in Code, Chat oder
Repository — auch nicht „nur kurz zum Testen".

**Warum reicht Pro nicht für Firmendaten?**
Weil es dazu keinen Auftragsverarbeitungsvertrag nach Art. 28 DSGVO gibt. Den gibt es erst ab dem
Team-Plan. Das ist eine Vertragsfrage, keine Einstellungsfrage.

**Was macht der Trainingsschalter?**
Aus: keine Nutzung zur Modellverbesserung, Aufbewahrung rund 30 Tage. An: Nutzung möglich, Aufbewahrung
bis zu fünf Jahre. Für Arbeitsbezug: aus.

**Wie neutralisiert man richtig?**
Struktur behalten, Inhalte ersetzen. Tabellen- und Spaltennamen verallgemeinern, Werte erfinden,
Zuordnungstabelle offline behalten. Für Modellarbeit ist die Struktur ohnehin alles, was zählt.

**Was ist beim Browser-Agenten das eigentliche Risiko?**
Er handelt mit den Rechten des angemeldeten Menschen. Auf Firmenanwendungen gehört das nur nach
ausdrücklicher Freigabe, und Berechtigungen immer je Website statt pauschal.

**Was tun, wenn versehentlich Echtdaten im Chat gelandet sind?**
Unterhaltung löschen, Vorfall festhalten, bei Personenbezug die Datenschutzbeauftragte informieren.
Nicht stillschweigend weiterarbeiten — das macht aus einem Versehen ein Verschweigen.

---

## Arbeitsweise

**Warum „erst planen, dann bauen"?**
Weil ein Plan in zwei Minuten korrigiert ist und eine falsch gebaute Lösung in zwei Stunden. Planmodus
nutzen, Plan lesen, dann freigeben.

**Warum ein Thema pro Unterhaltung?**
Weil der Kontext begrenzt ist und vermischte Themen sich gegenseitig verdrängen. Fertig heißt:
dokumentiert, dann neu anfangen.

**Warum den Arbeitspfad eng halten?**
Weil eine Freigabe lesen und schreiben bedeutet. Claude Code im Projektordner starten, nie im
Benutzerverzeichnis.

**Woran erkennt man, dass etwas fertig ist?**
An einer prüfbaren Bedingung, die vorher aufgeschrieben wurde — nicht am Gefühl. Deshalb hat jeder
Baustein einen Prüfabschnitt.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.0*
