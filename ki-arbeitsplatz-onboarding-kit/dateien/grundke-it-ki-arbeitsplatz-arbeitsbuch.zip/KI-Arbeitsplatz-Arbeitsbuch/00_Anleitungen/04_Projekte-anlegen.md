# 04 · Projekte anlegen und Struktur aufbauen

## Warum überhaupt Projekte

Ein Projekt ist ein Behälter mit eigener Anweisung und eigenem Wissen. Jeder Chat darin startet bereits
im richtigen Kontext — man muss nicht mehr jedes Mal erklären, worum es geht.

Wichtig zu wissen: **Kontext wird zwischen den Chats eines Projekts nicht automatisch geteilt.** Was
dauerhaft gelten soll, gehört ins Projektwissen (Dateien) oder in die Projektanweisung — nicht in einen
Chat, den man später sucht.

## Der Schnitt: zwei Welten, hart getrennt

| Projekt | Zweck | Datenlage |
|---|---|---|
| **Privat** | Haushalt, Finanzen, Reisen, Hobby, Weiterbildung | eigene Daten, unkritisch |
| **Beruf / Fachbereich** | Fachliche Methodik, Modelle, Auswertungen, Konzepte | **neutralisiert oder erfunden** |

Die Trennung ist keine Ordnungsliebe. Sie verhindert, dass eine private Frage im Arbeitskontext
beantwortet wird und — deutlich wichtiger — dass Arbeitsinhalte in einer privaten Unterhaltung landen.

Wer mehrere klar getrennte berufliche Themen hat, macht daraus mehrere Projekte. Faustregel: ein Projekt
pro Sache, für die man eine eigene Ablage hätte.

## Projekt anlegen

1. **claude.ai/projects** → **Neues Projekt**
2. Name kurz und eindeutig. Beschreibung ist für Menschen, nicht für Claude.
3. **Projektanweisungen setzen** — im Wissensbereich „Set project instructions".
   Vorlagen in `20_Projektvorlagen/`.
4. **Projektwissen hochladen:** die `CLAUDE.md`, das Design-System, ggf. ein Glossar.

### Was in die Projektanweisung gehört

Erste Zeile immer der Datenrahmen. Danach fachlicher Kontext, Rollenerwartung, Ausgabeformat, was ohne
Rückfrage geändert werden darf und was nicht.

## Die CLAUDE.md — diktieren statt tippen

Die schnellste Art, eine gute `CLAUDE.md` zu bekommen: sie sich abfragen lassen. Neuen Chat im Projekt
öffnen und sagen:

> Wir legen die CLAUDE.md für dieses Projekt an. Frag mich der Reihe nach ab, was in die Vorlage gehört —
> eine Frage nach der anderen, warte jeweils auf meine Antwort. Am Ende schreibst du die fertige Datei.
> Vorlage ist angehängt.

Das lässt sich vollständig diktieren, dauert fünf bis zehn Minuten und liefert ein besseres Ergebnis als
selbst getippt, weil nichts vergessen wird.

### Der Fragenkatalog, den Claude abarbeiten sollte

1. Was ist das Ziel dieses Projekts in einem Satz?
2. Für wen ist das Ergebnis — wer liest es, wer entscheidet damit?
3. Welche Fachbegriffe muss jemand kennen, der neu dazukommt?
4. Welche Werkzeuge und Formate sind im Einsatz?
5. Welche Daten liegen hier — echt, neutralisiert, erfunden, nur Struktur?
6. Welche Namenskonventionen gelten?
7. Was darf ohne Rückfrage geändert werden, was nie?
8. Welche Entscheidungen sind offen und wer trifft sie?
9. Wie ist der Stand heute, was ist der nächste Schritt?
10. Welche Sonderfälle sind schon einmal schiefgegangen?

Frage 10 ist die wertvollste und wird fast immer vergessen.

## Ordnerstruktur auf dem Rechner

```
KI-Arbeit/
  00_Wurzel/
    CLAUDE.md              globale Regeln
    LANDKARTE.md           welches Thema liegt wo
  01_Privat/
    <thema>/
      CLAUDE.md
      STATUS.md
      daten/  ergebnisse/
  02_Beruf/
    <thema>/
      CLAUDE.md
      STATUS.md
      sql/  dax/  doku/  testdaten/  ergebnisse/
  99_Vorlagen/
    muster-md/  skills/  design-system/
```

Nur `KI-Arbeit/` in der Desktop-App freigeben — damit ist der Wirkungskreis auf dem Rechner klar
begrenzt.

## Namensschema

Ein einfaches Schema erspart später viel Sucherei:

```
<Bereich>-<Thema>-<Objekt>
```

Also `beruf-vertriebskennzahlen-datenmodell` statt `Neuer Ordner (3)`. Das gilt für Ordner, Dateien,
Projekte und Chats gleichermaßen. Nach hundert Unterhaltungen ist das der einzige Grund, warum man noch
etwas wiederfindet.

## Die Landkarte

Eine Datei, die alle Themen auflistet: Name, wo der Ordner liegt, welches Projekt dazugehört, Status in
einem Wort. Sie ist die Antwort auf die Frage „was habe ich eigentlich alles offen". Zwei Minuten
Pflege je Thema, dafür jederzeit Überblick.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
