# 08 · Datenschutz und Grenzen

Das unbequemste Kapitel und zugleich das wichtigste. Wer es überspringt, baut kein Werkzeug, sondern
ein Risiko.

*Dieses Dokument ist eine fachliche Orientierung, keine Rechtsberatung. Im Zweifel entscheidet die
Datenschutzbeauftragte des Hauses, nicht dieses Kit.*

## Die Ausgangslage in vier Sätzen

1. Ein privates Einzelabo (Pro oder Max) läuft unter **Verbraucherbedingungen**.
2. Dazu gibt es **keinen Auftragsverarbeitungsvertrag nach Art. 28 DSGVO**. Den gibt es erst ab dem
   Team-Plan unter den Commercial Terms.
3. Wer im Auftrag eines Arbeitgebers oder Kunden personenbezogene Daten verarbeitet, **braucht** diesen
   Vertrag. Ohne ihn fehlt die rechtliche Grundlage — unabhängig davon, wie sorgfältig man technisch
   arbeitet.
4. Eine **EU-Datenresidenz für die Claude-Apps ist nicht dokumentiert.** Regionale Verarbeitung
   innerhalb Europas gibt es nur auf Schnittstellenebene über die großen Cloud-Anbieter.

Daraus folgt keine Blockade, sondern eine klare Trennung: **Methodik ja, Personendaten nein.**

## Die gute Nachricht

Für praktisch alles, was fachlich wertvoll ist, braucht man keine echten Personendaten:

| Aufgabe | Braucht Echtdaten? |
|---|---|
| Abfragen schreiben und optimieren | nein — Struktur genügt |
| Kennzahlen entwerfen, erklären, dokumentieren | nein — Definition genügt |
| Datenmodell prüfen | nein — Metadaten genügen |
| Berechtigungskonzept entwerfen und prüfen | nein — Rollen und Gruppen genügen |
| Testdaten erzeugen | nein — im Gegenteil |
| Dokumentation schreiben | nein |
| Ausführungspläne analysieren | nein |
| Konkrete Zahlen auswerten und interpretieren | **ja** — und deshalb nicht hier |

Die einzige Aufgabe in dieser Liste, die echte Daten braucht, ist die, die man ohnehin im
Fachsystem erledigt.

## Der Datenrahmen — zum Kopieren

Gehört in die kontoweiten Anweisungen **und** in jede Projektanweisung:

```
In dieses Konto kommen ausschließlich:
- erfundene oder synthetisch erzeugte Daten,
- neutralisierte Strukturen (Tabellen-, Spalten- und Kennzahlennamen ohne Personenbezug),
- öffentlich zugängliche Informationen,
- meine eigenen fachlichen Überlegungen.

Nicht hinein kommen:
- personenbezogene Daten (Namen, Vertragsnummern, Adressen, Geburtsdaten, Gesundheitsdaten),
- vertrauliche Geschäftszahlen des Arbeitgebers,
- Zugangsdaten, Schlüssel, Verbindungszeichenfolgen,
- Auszüge aus Produktivsystemen jeder Art.

Wenn dir auffällt, dass ich versehentlich etwas davon einfüge: sag es mir,
bevor du damit arbeitest.
```

## Neutralisieren — wie es praktisch geht

**Strukturen behalten, Inhalte ersetzen.** Für Modellarbeit, Kennzahlen und Berechtigungslogik ist die
Struktur ohnehin alles, was zählt.

| Original | Neutralisiert |
|---|---|
| `F_Vertrag_Lebensversicherung_Bestand` | `F_Vertrag` |
| Versicherungsnummer `LV-2019-0083412` | `VTR-00001` |
| Name `Maria Berger` | `Person_00042` |
| Beitrag `1.284,50 €` | erfundener Wert derselben Größenordnung |
| Vermittler `Agentur Schmidt, München` | `Vermittler_07` |

Bei den Namen von Tabellen und Spalten reicht es meist, Fachbegriffe zu verallgemeinern. Wenn schon der
**Name** eines Feldes vertraulich ist — was vorkommt —, wird auch er ersetzt und die Zuordnung bleibt
offline.

## Der Trainingsschalter

Einstellungen → Datenschutz → **„Help improve Claude"**.

- **Aus** → Aufbewahrung rund 30 Tage, keine Nutzung zur Modellverbesserung
- **An** → Aufbewahrung bis zu fünf Jahre

Für alles mit Arbeitsbezug: **aus**. Das ersetzt keinen Vertrag, reduziert aber die Angriffsfläche
erheblich.

Ergänzend: Unterhaltungen im **Inkognito-Modus** fließen grundsätzlich nicht in Verbesserung oder
Gedächtnis ein.

## Wenn der Arbeitgeber ins Spiel kommt

Sobald irgendetwas aus der Arbeitswelt eine Rolle spielt — auch nur interne Begriffe oder
Schemanamen — gehört das vorher geklärt:

- **IT-Security / Informationssicherheit:** Ist das Werkzeug freigegeben? Gibt es eine Positivliste?
- **Datenschutzbeauftragte:** Welche Datenklassen dürfen wohin?
- **Betriebsrat:** In vielen Häusern ist KI-Einsatz am Arbeitsplatz mitbestimmungspflichtig.
- **Compliance:** In regulierten Branchen — Banken, Versicherungen — kommen Aufsichtsanforderungen
  hinzu, etwa zur Auslagerung und zum Umgang mit Dienstleistern.

Bis eine Antwort vorliegt gilt: **allgemeines Fachwissen ja, Hausinterna nein.** Das ist keine
Schikane, sondern der Unterschied zwischen einem Vorzeigeprojekt und einem Meldevorfall.

**Der beste Weg, diese Gespräche zu führen:** nicht um Erlaubnis fragen, ob man „KI nutzen darf",
sondern zeigen, was man an neutralisierten Daten gebaut hat, und fragen, was nötig wäre, um es auf echte
Daten zu heben. Das verschiebt das Gespräch von einer Grundsatzfrage zu einer Umsetzungsfrage.

## Der Schritt danach: wenn es doch Echtdaten sein sollen

Dann braucht es einen anderen Aufbau, nicht ein anderes Vorgehen im selben Konto:

1. Firmenkonto (Team oder Enterprise), abgeschlossen vom Haus, nicht privat
2. Auftragsverarbeitungsvertrag — bei Team/Enterprise Bestandteil der Commercial Terms
3. Verarbeitungsverzeichnis ergänzen, ggf. Datenschutz-Folgenabschätzung
4. Beteiligung von Betriebsrat und Compliance abgeschlossen
5. Erst dann Anbindung an Fachsysteme

Wer diesen Weg gehen will, macht das mit dem Haus — nicht neben ihm.

## Prüfliste vor jeder Sitzung

- [ ] Bin ich im richtigen Projekt?
- [ ] Ist das, was ich gleich einfüge, neutralisiert?
- [ ] Enthält die Datei versteckte Inhalte — Kommentare, Verbindungszeichenfolgen,
      alte Tabellenblätter, Metadaten?
- [ ] Wenn ich mir unsicher bin: erst neutralisieren, dann einfügen.

Der letzte Punkt ist der einzige, der wirklich zählt. Unsicherheit ist das Signal, nicht das Problem.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
