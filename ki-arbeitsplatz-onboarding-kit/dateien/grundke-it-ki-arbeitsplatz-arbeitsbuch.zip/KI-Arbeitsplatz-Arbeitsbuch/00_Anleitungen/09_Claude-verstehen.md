# 09 · Claude verstehen — die Grundlagen

Kein Prompt-Trickbuch. Sechs Dinge, die man wirklich verstanden haben muss.

## 1. Das Kontextfenster

Alles, was Claude gerade „sieht", steht in einem begrenzten Arbeitsspeicher: die Anweisungen, die
hochgeladenen Dateien, der bisherige Gesprächsverlauf. Ist er voll, geht Frühes verloren — leise, ohne
Warnung.

**Was daraus folgt:**

- Ein Thema pro Unterhaltung. Ist es fertig, wird dokumentiert und eine neue begonnen.
- Was dauerhaft gelten soll, gehört in Anweisungen, Projektwissen oder eine `CLAUDE.md` — nicht in eine
  Chatnachricht, die irgendwann herausfällt.
- Wenn Claude plötzlich etwas „vergisst", was am Anfang klar war: der Kontext ist voll. Neu anfangen und
  das Wesentliche mitgeben, statt zu diskutieren.

## 2. Was Claude nicht wissen kann

- **Ereignisse nach dem Wissensstand** des Modells — dafür wird gesucht
- **Alles Hausinterne**, was nicht mitgegeben wurde
- **Den eigenen Bildschirm**, außer über Werkzeuge und Konnektoren

Ein Modell, das raten darf, rät — und zwar plausibel klingend. Deshalb steht in der Vorlage für die
kontoweiten Anweisungen der Satz „nachfragen statt raten". Er ist wirksamer als jeder Prompt-Kniff.

## 3. Das Prompt-Grundgerüst

Vier Bausteine, die zusammen fast alle Qualitätsprobleme lösen:

| Baustein | Zweck | Beispiel |
|---|---|---|
| **Rolle** | Tiefe und Blickwinkel festlegen | „Du bist erfahren in MS SQL und Power BI." |
| **Aufgabe** | Was genau zu tun ist | „Optimiere diese Abfrage." |
| **Kontext** | Rahmen, Daten, Randbedingungen | „Historisiertes Datenlager, SQL Server 2019, 40 Mio. Zeilen." |
| **Format** | Wie das Ergebnis aussehen soll | „Tabelle mit Befund und Empfehlung, dann das kommentierte Skript." |

Wer Rolle und Format dauerhaft in die kontoweiten Anweisungen legt, muss sie nie wieder tippen.

## 4. Vier Techniken, die tatsächlich wirken

**Beispiele geben.** Ein gutes und ein schlechtes Beispiel des gewünschten Ergebnisses sagen mehr als
drei Absätze Erklärung.

**Erst denken lassen.** Bei Analysen und Logik: „Geh erst schrittweise durch, dann gib das Ergebnis."
Senkt die Fehlerquote messbar.

**Material und Auftrag trennen.** Wenn viel Material dabei ist, in Abschnitte gliedern — etwa mit
Überschriften oder Auszeichnungen wie `<daten>` und `<auftrag>`. Dann ist klar, was Anweisung ist und
was Stoff.

**Nachsteuern statt neu anfangen.** Passt das Ergebnis nicht, sagt man konkret, was fehlt. Iterieren ist
der Normalfall, nicht das Eingeständnis eines schlechten Prompts.

## 5. Die Werkzeuge — welches wann

| Werkzeug | Wofür | Wo |
|---|---|---|
| **Chat** | Denken, planen, erklären lassen, schreiben | überall |
| **Projekte** | Dauerhafter Rahmen für ein Thema | Web und App |
| **Cowork** | Mehrstufige Aufgaben, Dateiarbeit, Ausliefern | Desktop-App, Web, mobil |
| **Claude Code** | Arbeiten in Ordnern und Dateien, Skripte, SQL | Terminal, VS Code |
| **Design** | Oberflächen, Dashboards, Foliensätze gestalten | Web und App |
| **Browsererweiterung** | Webseiten bedienen, Recherche mit Klicks | Chrome |
| **Office-Erweiterungen** | Direkt in Excel, PowerPoint, Word | Office |

**Die übliche Kette:** Chat (verstehen und planen) → Design (wie es aussehen soll) → Claude Code
(bauen) → Cowork (ausliefern). Nicht jede Aufgabe braucht alle vier — aber die Reihenfolge stimmt fast
immer.

## 6. Die Modelle

Es gibt mehrere Modelle, grob abgestuft:

- **Schnell und sparsam** — Routine, Klassifizieren, Kurzantworten, große Mengen
- **Allrounder** — der Normalfall für die meiste Arbeit
- **Stark** — komplexe Architektur, schwierige Analysen, längere eigenständige Arbeit
- **Am stärksten** — die anspruchsvollsten Aufgaben, deutlich höherer Verbrauch

Faustregel: mit dem Allrounder anfangen, bei echter Komplexität hochgehen, bei Massenaufgaben
heruntergehen. Die stärkeren Modelle verbrauchen erheblich mehr vom Kontingent — das ist der eigentliche
Grund, bewusst zu wählen. Welche Modelle das eigene Konto anbietet, zeigt in Claude Code der Befehl
`/model`.

## Was Claude nicht ersetzt

Fachliche Verantwortung. Jedes Ergebnis wird geprüft, bevor es benutzt wird — besonders bei Zahlen,
Formeln und allem, was jemand anderes für eine Entscheidung heranzieht. Ein Modell, das sich irrt, tut
das ebenso souverän wie eines, das recht hat. Diese Prüfung ist keine Schwäche des Werkzeugs, sondern
der Grund, warum die Fachkraft davor sitzt.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.0*
