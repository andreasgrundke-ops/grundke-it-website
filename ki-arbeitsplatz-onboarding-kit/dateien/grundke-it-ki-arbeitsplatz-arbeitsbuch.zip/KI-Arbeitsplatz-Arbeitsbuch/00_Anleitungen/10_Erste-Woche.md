# 10 · Die erste Woche — an echten Aufgaben üben

Keine Tutorials. Sechs Übungen an der eigenen Arbeit, alle ohne Echtdaten machbar, sortiert nach
„sofort sichtbarer Nutzen".

---

## Übung 1 · Eine geerbte Kennzahl erklären lassen

**Zeit:** 10 Minuten · **Risiko:** keins

Eine komplizierte Formel, die man geerbt hat und nie ganz verstanden hat, in den Chat einfügen (nur die
Formel, keine Daten) und bitten:

> Erklär mir diese Kennzahl in normalem Deutsch: was sie berechnet, in welchem Auswertungszusammenhang
> sie sich wie verhält, und wo die Fallstricke liegen. Danach schreib mir eine
> Dokumentationsbeschreibung dazu, die ein Fachbereich versteht.

**Warum zuerst:** sofort nützlich, null Risiko, und das Ergebnis wandert direkt in die Dokumentation.
Nebenbei zeigt es, wie gut das Werkzeug im eigenen Fachgebiet tatsächlich ist.

---

## Übung 2 · Eine langsame Abfrage optimieren lassen

**Zeit:** 30 Minuten · **Risiko:** gering, wenn man sich an die Regel hält

Abfrage plus Ausführungsplan geben (Tabellen- und Spaltennamen bei Bedarf neutralisieren):

> Diese Abfrage ist langsam. Hier ist der Ausführungsplan. Nenn mir die drei wahrscheinlichsten Ursachen
> mit Begründung, dann Verbesserungsvorschläge, jeweils mit dem Risiko, das damit einhergeht.

**Die Regel:** Vorschläge zuerst auf einer Testumgebung prüfen. Nie direkt produktiv, egal wie einleuchtend
die Begründung klingt.

---

## Übung 3 · Testdaten erzeugen lassen

**Zeit:** 45 Minuten · **Risiko:** keins — es entstehen ja gerade keine echten Daten

Nicht die Daten erzeugen lassen, sondern **das Skript**, das sie erzeugt. Ein Skript ist reproduzierbar,
prüfbar und versionierbar; von einem Modell direkt ausgeschriebene Zeilen sind es nicht.

> Schreib mir ein Python-Skript, das für dieses Modell plausible Testdaten erzeugt: [Struktur beschreiben].
> Feste Zufallsbasis, damit es reproduzierbar ist. Realistische Verteilungen, keine Gleichverteilung.
> Am Ende Plausibilitätsprüfungen, die durchlaufen müssen.

Bei Schadens- oder Kostendaten unbedingt auf **rechtsschiefe Verteilungen** bestehen — mit
gleichverteilten Werten fehlen die Großfälle, und dann ist jede daraus gebaute Kennzahl unbrauchbar.

Der Skill `testdaten-generator` gibt das Vorgehen vor.

---

## Übung 4 · Berechtigungen sichtbar machen

**Zeit:** 1–2 Stunden · **Risiko:** gering — reine Metadaten

Die größte Zeitersparnis im Berufsalltag und zugleich harmlos, weil keine Fachdaten im Spiel sind.

Rollen-, Gruppen- und Zuweisungsexporte (nur Metadaten, Personennamen bei Bedarf pseudonymisiert) geben
und prüfen lassen:

- Personen in sich gegenseitig ausschließenden Rollen
- Rechte, die Zeilenfilter unbemerkt aushebeln
- Gruppen ohne Mitglieder, Berichte ohne jede Zuweisung
- Abweichungen zwischen Soll- und Ist-Zuordnung

**Der Klassiker:** Wer über eine Bearbeitungsrolle statt einer reinen Leserolle zugreift, umgeht
Zeilenfilter vollständig. Ein Audit findet das in Minuten; manuelle Pflege findet es nie. Genau das ist
das Argument, mit dem man den nächsten Schritt begründet.

Skill: `berechtigungs-audit`.

---

## Übung 5 · Ein Ergebnis im eigenen Design

**Zeit:** 30 Minuten · **Risiko:** keins

Eine kleine Auswertung als Arbeitsmappe oder Foliensatz bauen lassen — mit dem Design-System aus Phase 4
als Vorgabe.

> Bau mir daraus eine Arbeitsmappe: Datenblatt, Kennzahlenblatt, ein Diagramm. Formatierung nach dem
> angehängten Design-System. Eingabezellen farblich markiert, Formeln nachvollziehbar.

Zeigt sofort, ob Phase 4 ordentlich gemacht wurde. Sieht das Ergebnis beliebig aus, war das
Design-System zu vage.

---

## Übung 6 · Ein eigenes Skill schreiben

**Zeit:** 1 Stunde · **Wirkung:** dauerhaft

Eine Hausregel nehmen, die man ohnehin ständig erklärt — eine Namenskonvention, ein Kommentarschema,
eine Prüfliste — und als `SKILL.md` festhalten. Am schnellsten so:

> Ich will ein Skill bauen, das folgende Regel dauerhaft anwendet: [Regel erklären]. Frag mich ab, was
> hineingehört, und schreib dann die SKILL.md nach dem Muster im angehängten Beispiel.

Ab dann wendet Claude die Regel von selbst an — bei jeder passenden Anfrage, ohne dass man sie erwähnt.
Das ist der Moment, in dem aus einem Werkzeug ein Arbeitsplatz wird.

---

## Nach der Woche: Ehrliche Zwischenbilanz

Drei Fragen, schriftlich beantwortet:

1. **Was hat tatsächlich Zeit gespart?** Nicht was beeindruckend war — was Zeit gespart hat.
2. **Wo war das Ergebnis falsch oder unbrauchbar?** Diese Fälle sind die wertvollsten: Sie zeigen, wo
   Kontext fehlt oder ein Skill gebraucht wird.
3. **Was war umständlicher als vorher?** Auch das kommt vor und gehört benannt statt weggeredet.

Aus den Antworten entstehen die nächsten zwei Skills und die nächste Fassung der Projektanweisung. Das
ist die eigentliche Einarbeitung — nicht die Installation.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
