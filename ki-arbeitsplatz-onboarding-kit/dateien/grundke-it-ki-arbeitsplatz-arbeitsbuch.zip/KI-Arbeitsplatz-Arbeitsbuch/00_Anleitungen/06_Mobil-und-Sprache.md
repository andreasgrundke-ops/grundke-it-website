# 06 · Mobil und Sprache

## Installation

| Gerät | Wo | Voraussetzung |
|---|---|---|
| iPhone / iPad | App Store, „Claude by Anthropic" | iOS 17 oder neuer |
| Android | Play Store | Android 8 oder neuer |

Mit demselben Konto anmelden. Projekte, Gedächtnis, kontoweite Anweisungen und der Gesprächsverlauf
sind sofort da — es gibt nichts zusätzlich einzurichten.

## Sprachmodus

Wellen-Symbol im Eingabefeld. Zwei Betriebsarten: freihändig (Claude hört durchgehend zu) oder
Halten-zum-Sprechen. Der Wechsel zwischen Sprechen und Tippen ist innerhalb derselben Unterhaltung
möglich.

Der Sprachmodus zählt auf dieselben Nutzungsgrenzen wie alles andere.

### Wofür er wirklich taugt

- **Gedanken festhalten**, bevor sie weg sind — auf dem Weg zur Arbeit, nach einem Gespräch
- **Sich etwas erklären lassen**, während die Hände beschäftigt sind
- **Diktieren statt tippen** bei längeren Texten: erst frei sprechen, dann am Rechner aufräumen lassen

### Wofür er nicht taugt

Genaues Arbeiten mit Code, Tabellen oder Zahlen. Dafür braucht es einen Bildschirm.

### Ein Hinweis zum Diktieren

Diktierte Texte enthalten Erkennungsfehler — verhörte Fachbegriffe, falsche Eigennamen, fehlende
Satzzeichen. Es lohnt sich, in die kontoweiten Anweisungen einen Satz aufzunehmen:

> Ich diktiere häufig. Rechne mit Erkennungsfehlern bei Fachbegriffen und frag nach, wenn etwas
> offensichtlich verhört ist, statt es wörtlich zu nehmen.

## Was mobil geht und was nicht

| Funktion | Mobil |
|---|---|
| Chat, Projekte, Gedächtnis, Verlauf | ja |
| Konnektoren aus dem Verzeichnis nutzen | ja |
| Eigene Konnektoren **einrichten** | am Rechner |
| Lokale Dateien | nein — nur über die Desktop-App |
| Dateien erzeugen und herunterladen | ja |

## Zusammenspiel im Alltag

Das Muster, das sich in der Praxis bewährt:

1. **Unterwegs** eine Idee, ein Problem oder eine halbe Anforderung diktieren — in das passende Projekt
2. **Am Schreibtisch** dieselbe Unterhaltung fortsetzen, mit Dateien, Struktur und Werkzeugen
3. **Am Ende** das Ergebnis in `STATUS.md` festhalten

Das Telefon ist der Eingang, der Rechner die Werkstatt. Wer beides trennt, verliert die halbe
Produktivität; wer beides vermischt, verliert die Übersicht.

## Kurzbefehl einrichten (iPhone)

Über die Kurzbefehle-App lässt sich ein Ablauf anlegen, der direkt in einen neuen Chat springt — auf den
Sperrbildschirm oder als Widget. Spart den Umweg über den Startbildschirm und senkt die Hürde, etwas
tatsächlich festzuhalten.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
