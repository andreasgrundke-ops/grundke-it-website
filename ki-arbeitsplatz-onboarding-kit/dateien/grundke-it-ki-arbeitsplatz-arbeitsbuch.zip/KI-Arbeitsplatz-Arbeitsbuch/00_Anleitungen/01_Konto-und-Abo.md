# 01 · Konto und Abo

## Die Pläne im Überblick (Stand August 2026)

| Plan | Grob | Enthält | Für wen |
|---|---|---|---|
| Free | 0 | Chat, Websuche, Gedächtnis, Konnektoren aus dem Verzeichnis | Ausprobieren |
| **Pro** | **rund 20 USD/Monat**, jährlich günstiger | Free + **Claude Code**, **Cowork**, **Design**, Projekte | **Der Einstieg für ernsthafte Einzelarbeit** |
| Max | ab rund 100 USD/Monat | wie Pro, mit 5- bis 20-fachem Nutzungsvolumen | Wer täglich lange am Stück arbeitet |
| Team | ab 2 Sitzen, rund 20–25 USD/Sitz | Pro-Funktionen + Verwaltung, Freigaben, **Commercial Terms** | Firmen |
| Enterprise | auf Anfrage | Team + Protokollierung, eigene Aufbewahrungsfristen, RBAC | Konzerne |

Preise können je nach Region, Währung und App-Plattform abweichen — im Zweifel gilt die Anzeige beim
Abschluss, nicht diese Tabelle.

## Warum Pro und nicht Free

Der kostenlose Plan enthält **weder Claude Code noch Cowork**. Ohne diese beiden bleibt Claude ein
besserer Chat: keine Arbeit an lokalen Dateien, keine mehrstufigen Aufgaben, keine Skripte, die
tatsächlich laufen. Der Sprung von Free auf Pro ist der größte Funktionsunterschied im gesamten Angebot.

## Der Punkt, der oft übersehen wird: Nutzungsgrenzen

Es gibt zwei ineinandergreifende Fenster:

- ein **rollierendes Fenster von etwa fünf Stunden**
- ein zusätzliches **Wochenlimit**

Beide sind **gemeinsam** für Chat, Claude Code und Cowork — wer vormittags im Chat viel schreibt, hat
nachmittags in Claude Code weniger. Das stärkste Modell verbraucht dabei erheblich mehr als die
schnelleren.

Praktisch heißt das: Für Lernen, Dokumentation, Auswertungen und normale Büroarbeit reicht Pro gut aus.
Wer Claude Code stundenlang an einem größeren Datenbankprojekt arbeiten lässt, wird die Grenzen
erreichen. **Diese Entscheidung gehört nach zwei bis drei Wochen echter Nutzung getroffen, nicht
vorher.** Ein Upgrade auf Verdacht kostet Geld ohne Erkenntnisgewinn.

## Registrierung — Schritt für Schritt

1. **claude.ai** öffnen, mit einer **privaten** Mailadresse registrieren.
   Nicht mit der Firmenadresse: sonst hängt das Konto möglicherweise am Tenant des Arbeitgebers und die
   saubere Trennung zwischen privat und beruflich ist von Anfang an verwaschen.
2. Mailadresse bestätigen, starkes Passwort im Passwortmanager ablegen.
3. **Zwei-Faktor-Anmeldung** aktivieren, Wiederherstellungscodes ebenfalls in den Passwortmanager.
4. Abo abschließen: Einstellungen → Abrechnung → Pro.
5. **Verlängerungsdatum in den Kalender.** Ein Abo, das sich unbemerkt verlängert, ist ein Ärgernis;
   eines, das man bewusst verlängert, ist eine Entscheidung.

## Sofort danach: der Datenschutzschalter

Einstellungen → Datenschutz → **„Help improve Claude"** (Modellverbesserung).

- **Aus** — Unterhaltungen werden nicht zur Modellverbesserung genutzt, Aufbewahrung rund 30 Tage.
- **An** — Unterhaltungen können zur Verbesserung genutzt werden, Aufbewahrung bis zu fünf Jahre.

Bei Verbraucherplänen ist das eine bewusste Zustimmung, keine stille Voreinstellung. Für alles, was mit
Arbeit zu tun hat: **aus**. Zusätzlich gibt es Unterhaltungen im Inkognito-Modus, die grundsätzlich nicht
zur Verbesserung verwendet werden.

## Was Pro ausdrücklich nicht leistet

**Es gibt keinen Auftragsverarbeitungsvertrag (Art. 28 DSGVO) für Pro oder Max.** Der Vertrag hängt an
den Commercial Terms und damit am Team- oder Enterprise-Plan. Wer im Auftrag eines Arbeitgebers oder
Kunden personenbezogene Daten verarbeitet, braucht mindestens Team — daran ändert keine technische
Einstellung etwas.

Ebenso: **Eine EU-Datenresidenz für die Claude-Apps ist nicht dokumentiert.** Regionale Verarbeitung
innerhalb Europas gibt es nur auf Schnittstellenebene über die großen Cloud-Anbieter. Wer das braucht,
baut anders — nicht mit einem Einzelabo.

Beides ist kein Grund, nicht anzufangen. Es ist der Grund, warum Phase 0 des Punkteplans existiert.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.0*
