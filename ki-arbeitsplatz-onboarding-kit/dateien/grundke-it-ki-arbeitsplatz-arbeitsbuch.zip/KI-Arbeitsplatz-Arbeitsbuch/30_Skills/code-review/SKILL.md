---
name: code-review
description: Strukturierte Durchsicht von Code und Skripten — Korrektheit, Fallstricke, Wartbarkeit, Sicherheit. Nutzen bei "prüf mal", "review", "kann das so weg", vor Übergabe oder bei übernommenem fremdem Code.
---

# Code-Review

## Regel Nummer eins

**Zuerst in eigenen Worten sagen, was der Code fachlich tut.** Gelingt das nicht, ist das der erste
Befund — vor jedem Stilhinweis. Unverständlicher Code ist ein Wartungsrisiko, egal wie korrekt er ist.

## Reihenfolge

1. **Korrektheit** — tut er, was er soll?
2. **Fallstricke** — was geht in Sonderfällen schief?
3. **Sicherheit** — Zugangsdaten, Einschleusung, Rechte
4. **Wartbarkeit** — versteht das jemand in einem Jahr?
5. **Stil** — zuletzt, und knapp

Wer bei 5 anfängt, produziert Reviews, die niemand mehr liest.

## Prüfpunkte

### Korrektheit
- Randfälle: leere Menge, ein Element, sehr viele Elemente
- Leere Werte und fehlende Daten — überall, wo sie vorkommen können
- Datums- und Zeitzonenlogik, Monats- und Jahresgrenzen
- Rundung und Genauigkeit, besonders bei Geldbeträgen
- Vervielfachung durch Verknüpfungen bei Aggregaten

### Fallstricke
- Stille Fehler: etwas geht schief, aber nichts meldet sich
- Annahmen über Datenqualität, die nirgends geprüft werden
- Reihenfolgeabhängigkeiten ohne festgelegte Sortierung
- Nebenwirkungen an Stellen, wo man keine erwartet

### Sicherheit
- Zugangsdaten, Schlüssel, Verbindungszeichenfolgen im Code — **immer ein Befund**
- Zusammengebaute Abfragen aus Eingaben statt Parametern
- Rechte weiter gefasst als nötig
- Protokollausgaben mit vertraulichen Inhalten

### Wartbarkeit
- Kopfzeile, Version, Änderungshistorie vorhanden
- Kommentare erklären das **Warum**, nicht das Was
- Namen sagen, was gemeint ist
- Wiederholungen, die eine Änderung an drei Stellen erzwingen
- Toter Code

## Ausgabeformat

```
## Was der Code tut
[in eigenen Worten, fachlich]

## Befunde

### 1. [Titel] — kritisch / wichtig / Hinweis
**Stelle:** Zeile X
**Problem:** ...
**Wann es weh tut:** [konkretes Szenario, nicht abstrakt]
**Vorschlag:** [Code oder Beschreibung]

## Was gut ist
[ehrlich — wenn etwas sauber gelöst ist, gehört das gesagt]

## Fazit
[kann so weg / mit den kritischen Punkten weg / überarbeiten]
```

## Haltung

- **Konkret statt allgemein.** „Fehlerbehandlung fehlt" hilft nicht. „Wenn die Quelldatei fehlt, bricht
  Zeile 34 mit einer unverständlichen Meldung ab" hilft.
- **Szenario dazu.** Jeder Befund braucht einen Fall, in dem er tatsächlich zuschlägt. Findet sich
  keiner, ist es ein Stilhinweis, kein Befund.
- **Nichts erfinden.** Was nicht im Code steht, wird nicht behauptet. Bei Unsicherheit: als Frage
  formulieren.
- **Gutes benennen.** Ein Review, das nur Fehler findet, wird als Nörgelei gelesen und verpufft.

## Hausergänzungen

> Eigene Vorgaben, verbotene Muster, Freigabewege, was in diesem Haus als kritisch gilt.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
