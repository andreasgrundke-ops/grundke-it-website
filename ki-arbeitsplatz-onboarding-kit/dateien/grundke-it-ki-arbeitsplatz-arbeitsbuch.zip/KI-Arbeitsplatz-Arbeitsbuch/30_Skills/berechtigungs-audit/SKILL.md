---
name: berechtigungs-audit
description: Berechtigungen in Berichtsplattformen aus Metadaten-Exporten prüfen — Rollen, Gruppen, Zuweisungen, Zeilenrechte. Findet Widersprüche, umgangene Filter, verwaiste Gruppen und fehlende Zuweisungen. Nutzen bei Berechtigungsprüfung, Rechteübersicht, Rezertifizierung oder wenn manuelle Rechtepflege abgelöst werden soll.
---

# Berechtigungs-Audit

Arbeitet **ausschließlich auf Metadaten**: Rollennamen, Gruppennamen, Zuweisungen, Filterausdrücke,
Berichtsnamen. Keine Fachdaten, keine Inhalte. Personennamen können vor dem Export durch Kennungen
ersetzt werden — für die Prüfung reicht das vollständig.

## Warum das die erste Aufgabe sein sollte

Manuelle Rechtepflege erzeugt zuverlässig drei Arten von Fehlern, die niemandem auffallen, weil sie
still sind: Rechte, die Filter aushebeln; Zuweisungen, die nach einem Wechsel stehen bleiben; und
Berichte, die niemand sieht. Ein Audit findet das in Minuten. Und weil keine Fachdaten im Spiel sind,
braucht es dafür keine Freigabe für Datenzugriff.

## Benötigte Exporte

| Export | Inhalt |
|---|---|
| Arbeitsbereichsrollen | wer hat welche Rolle in welchem Arbeitsbereich |
| App-Zielgruppen | welche Gruppe sieht welche Berichte |
| Zeilenrechte-Rollen | Rollenname, Tabelle, Filterausdruck |
| Rollenzuweisungen | welche Person oder Gruppe hängt an welcher Rolle |
| Verzeichnisgruppen | Gruppe, Mitglieder, Beschreibung |
| Berichtsliste | welche Berichte gibt es, in welchem Arbeitsbereich |
| Soll-Matrix | falls vorhanden: wer soll was sehen |

Formate egal — JSON, CSV, Tabelle. Fehlt ein Export, wird gesagt, welche Prüfungen dadurch entfallen,
statt mit Annahmen weiterzumachen.

## Prüfungen

### A · Rechte, die Filter aushebeln — höchste Priorität

Zeilenfilter wirken typischerweise **nur bei reinen Leserollen**. Wer eine Bearbeitungs-, Mitglieds-
oder Verwaltungsrolle hat, sieht alles — unabhängig von jedem Filter.

Prüfen:
- Personen mit Bearbeitungsrechten in Arbeitsbereichen, in denen Zeilenrechte definiert sind
- Personen, die gleichzeitig einer Zeilenrechte-Rolle **und** einer Bearbeitungsrolle zugeordnet sind
  (das ist das Muster, das aussieht wie Sicherheit und keine ist)
- Bearbeitungsrechte, die „nur vorübergehend" vergeben wurden und noch stehen

**Das ist der wichtigste Befund. Er kommt zuerst und einzeln.**

### B · Widersprüche

- Person in mehreren, sich fachlich ausschließenden Rollen
- Person über zwei Wege berechtigt, mit unterschiedlichem Ergebnis
- Rolle mit widersprüchlichen oder sich überlagernden Filterausdrücken

### C · Verwaiste Objekte

- Gruppen ohne Mitglieder, aber mit Zuweisungen
- Rollen ohne Zuweisung
- Berichte in keiner Zielgruppe — sichtbar für niemanden oder für alle
- Zuweisungen an Kennungen, die es nicht mehr gibt

### D · Filterausdrücke

- Ausdrücke, die auf Anmeldenamen aufsetzen: Wird der Wert im eigenen Verzeichnis wirklich in dem Format
  geliefert, das der Ausdruck erwartet? Bei Gästen und externen Konten weicht das regelmäßig ab.
- Filter auf Spalten, die es im Modell nicht mehr gibt
- Filter, die durch beidseitige Beziehungsfilterung umgangen werden können

### E · Soll gegen Ist

Wenn eine Soll-Matrix vorliegt: Abweichungen in beide Richtungen — zu viel Recht und zu wenig Recht.
Zu wenig Recht meldet sich von selbst, zu viel Recht nie.

## Ausgabeformat

```
## Zusammenfassung
| Prüfung | Geprüft | Befunde | Schwerste |
|---|---|---|---|
| Filter umgangen | 42 Zuweisungen | 3 | kritisch |
| ...

## Kritisch
### 1. [Titel]
**Betroffen:** ...
**Warum kritisch:** ...
**Nachweis:** [welche Zeilen aus welchem Export]
**Empfehlung:** ...

## Mittel
...

## Hinweise
...

## Nicht prüfbar
[Was mangels Export offen blieb — mit Angabe, welcher Export fehlt]
```

## Grenzen — ausdrücklich benennen

- Das Audit sieht nur, was in den Exporten steht. Rechte, die anderswo vergeben werden — direkt am
  Datenbestand, über Weitergabe einzelner Objekte, über Verwaltungsrechte auf höherer Ebene — sind
  unsichtbar.
- Ein sauberes Ergebnis heißt „in diesen Exporten kein Widerspruch", nicht „alles korrekt".
- **Änderungen werden nie selbst ausgeführt.** Ergebnis ist ein Befundbericht und ein Änderungsvorschlag
  zum Prüfen — kein Eingriff.

Diese Trennung ist kein Bremsklotz: In einem geprüften Umfeld wird sie ohnehin verlangt, und sie macht
die Automatisierung nachweisbar statt nur schnell.

## Weg aus der manuellen Pflege

Als Zielbild empfehlen: **Verzeichnisgruppen als einzige Quelle der Wahrheit.** Eine Gruppe steuert
Arbeitsbereichsrolle, Zielgruppe **und** Zeilenrechte-Zuweisung. Dann besteht die Pflege nur noch aus
Gruppenmitgliedschaften; alles andere folgt.

Der Weg dorthin in drei Schritten: erst der Ist-Bericht aus diesem Audit, dann die Soll-Matrix als
Gruppenmodell, dann schrittweise Umstellung mit erneutem Audit als Nachweis.

## Hausergänzungen

> Eigene Rollenkonventionen, Rezertifizierungsrhythmus, Berichtsempfänger, Vorgaben aus dem internen
> Kontrollsystem.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.0*
