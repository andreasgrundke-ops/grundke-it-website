---
name: seo-und-ki-suche
description: Auffindbarkeit in klassischen Suchmaschinen und in KI-Antworten — Struktur, Inhalt, technische Grundlagen, Zitierfähigkeit. Nutzen bei Website-Texten, Sichtbarkeit, "wir werden nicht gefunden", Inhalten die in KI-Antworten auftauchen sollen.
---

# Auffindbarkeit — klassisch und in KI-Antworten

## Was sich geändert hat

Klassische Suche liefert Links; ein Mensch klickt und entscheidet. KI-Antworten liefern eine
zusammengefasste Antwort und nennen Quellen. Das verschiebt die Anforderung:

| Klassisch | In KI-Antworten |
|---|---|
| ranken | **zitiert werden** |
| Klicks holen | in der Antwort **vorkommen** |
| Stichwortdichte | **eindeutige, belegbare Aussagen** |
| Titel und Beschreibung | **Abschnitte, die für sich stehen** |

Die gute Nachricht: Beides zieht in dieselbe Richtung. Ein Text, der klar strukturiert und belegbar ist,
funktioniert in beiden Welten. Tricks funktionieren in keiner.

## Was Zitierfähigkeit ausmacht

1. **Aussagen, die für sich stehen.** Ein Abschnitt muss verständlich sein, auch wenn er allein zitiert
   wird. Also nicht „wie oben beschrieben", sondern die Aussage noch einmal vollständig.
2. **Konkrete Zahlen und Fakten** statt Werbeaussagen. Zusammenfassungen greifen Überprüfbares auf.
3. **Frage-Antwort-Struktur.** Überschriften als echte Fragen, direkt darunter die Antwort in ein bis
   zwei Sätzen. Details danach.
4. **Aktualität sichtbar machen.** Datum, Stand, letzte Prüfung.
5. **Eindeutige Zuordnung.** Wer sagt das, mit welcher Fachkunde.

## Struktur einer Seite

```
H1   Ein Thema, klar benannt
     Einleitung: worum geht es, für wen — 2–3 Sätze

H2   [Frage, die jemand tatsächlich stellt]
     Antwort in 1–2 Sätzen. Danach Details.

H2   [Nächste Frage]
     ...

H2   Häufige Fragen
     Kurze Frage-Antwort-Paare
```

Eine H1 je Seite. Überschriften beschreiben den Inhalt, nicht das Layout.

## Technische Grundlagen

- Sprechende Adressen: `/berechtigungen-power-bi` statt `/seite?id=42`
- Titel 50–60 Zeichen, Beschreibung 140–160 — beide je Seite eigenständig
- Strukturierte Daten für Organisation, Ort, Fragen, Artikel
- Ladezeit und Darstellung auf dem Telefon
- Bilder mit aussagekräftigem Alternativtext
- Sitemap und `robots.txt` gepflegt
- Interne Verlinkung mit sprechendem Linktext — nicht „hier klicken"

## Für lokale Auffindbarkeit

- Name, Adresse, Telefon überall **identisch**, auch in der Schreibweise
- Ortsbezug in Titel und Text, aber natürlich
- Eigene Seite je Leistung, nicht alles auf einer

## Was nicht funktioniert

- Stichwörter stapeln — wird als Manipulation erkannt
- Texte ohne Substanz in Länge — wird als dünn bewertet
- Versteckter Text, Weiterleitungstricks — Risiko ohne Ertrag
- Massenweise erzeugte Seiten ohne eigenen Inhalt

## Messen

| Größe | Sagt aus |
|---|---|
| Aufrufe aus der Suche | klassische Sichtbarkeit |
| Position je Suchbegriff | wo man steht |
| Zugriffe ohne erkennbare Quelle | oft Menschen, die aus einer KI-Antwort kamen |
| Direkte Anfragen mit Bezug auf einen Inhalt | der ehrlichste Beleg |

Für Sichtbarkeit in KI-Antworten gibt es noch keine verlässliche Messgröße. Der praktikable Weg: die
eigenen Kernfragen regelmäßig in mehreren Assistenten stellen und prüfen, ob und wie man vorkommt.

## Hausergänzungen

> Eigene Suchbegriffe, Wettbewerb, Zielgruppen, Ortsbezug, gesetzte Formulierungen.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.0*
