---
name: marketing-text
description: Texte für Außenwirkung schreiben — Website, Angebot, Präsentation, Vorstellung, Beitrag. Klar, belegbar, ohne Werbefloskeln. Nutzen bei Texten, die andere Menschen überzeugen sollen.
---

# Texte mit Außenwirkung

## Die Regel, die alles trägt

**Konkret schlägt superlativ.** „Reduziert die manuelle Rechtepflege von wöchentlich auf monatlich"
schlägt „revolutioniert Ihr Berechtigungsmanagement" — immer, bei jeder Zielgruppe.

## Verbotene Wörter

Innovativ · revolutionär · nahtlos · ganzheitlich · maßgeschneidert · zukunftssicher · State of the Art ·
Rundum-sorglos · Synergien · Mehrwert · perfekt · einzigartig · Ihr verlässlicher Partner ·
„Wir leben Qualität"

Diese Wörter tragen keine Information. Ihr einziger Effekt ist, dass der Text austauschbar wird —
denn der Wettbewerb schreibt dasselbe.

**Ersatzregel:** Jede Behauptung braucht entweder eine Zahl, ein Beispiel oder sie fliegt raus.

## Aufbau

1. **Was ist es** — ein Satz, ohne Vorrede
2. **Für wen** — konkret, nicht „für Unternehmen jeder Größe"
3. **Welches Problem** — in den Worten des Lesers, nicht in Fachsprache
4. **Wie gelöst** — nachvollziehbar, nicht magisch
5. **Beleg** — Zahl, Beispiel, Referenz
6. **Nächster Schritt** — genau einer

## Ton

- Sie-Form im geschäftlichen Umfeld, außer die Zielgruppe erwartet es anders
- Aktiv, kurze Sätze, Gegenwart
- Kein Ausrufezeichen. Ein Text, der schreien muss, hat kein Argument.
- Fachbegriffe ja, wenn die Zielgruppe sie benutzt — sonst übersetzen
- Ehrlich über Grenzen. Das schafft mehr Vertrauen als jede Superlative.

## Längenvorgaben

| Format | Länge | Kern |
|---|---|---|
| Titel | 5–8 Wörter | Was, für wen |
| Untertitel | 1 Satz | Der konkrete Nutzen |
| Absatz | 3–4 Sätze | Ein Gedanke |
| Vorstellung mündlich | 30 Sekunden | Problem, Lösung, Beleg |
| Angebotszusammenfassung | halbe Seite | Was, wann, wie viel, was danach |

## Vor der Abgabe

- [ ] Steht in den ersten zwei Sätzen, worum es geht?
- [ ] Ist jede Behauptung belegt oder gestrichen?
- [ ] Kommt ein verbotenes Wort vor?
- [ ] Könnte der Wettbewerb denselben Text über sich schreiben? Dann ist er zu allgemein.
- [ ] Genau ein nächster Schritt, nicht drei?
- [ ] Vorgelesen — stolpert man irgendwo?

## Was ich nicht schreibe

Erfundene Kundenstimmen, erfundene Referenzen, erfundene Zahlen. Wenn ein Beleg fehlt, wird das gesagt
und der Satz umgebaut — nicht ein Beleg erfunden. Das ist keine Vorsicht, sondern der Unterschied
zwischen Werbung und Täuschung.

## Hausergänzungen

> Eigene Tonalität, Zielgruppen, Alleinstellungsmerkmale, Formulierungen die gesetzt sind, Freigabewege.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.0*
