---
name: datenmodell-review
description: Prüfliste für analytische Datenmodelle (Stern-Schema) — Struktur, Beziehungen, Granularität, Datumstabelle, Performance, Benennung. Nutzen, wenn ein Datenmodell entworfen, geprüft, übernommen oder umgebaut wird.
---

# Datenmodell-Review

Arbeitet auf Metadaten: Tabellen, Spalten, Datentypen, Beziehungen, Kennzahlen. **Keine Echtdaten
nötig** — und ausdrücklich nicht erwünscht.

## Ablauf

1. Modell aufnehmen (Tabellen, Beziehungen, Granularität je Tabelle)
2. Prüfliste durchgehen
3. Befunde nach Schwere sortieren
4. Je Befund: Wirkung und Empfehlung, nicht nur „ist falsch"
5. Bewertung als Tabelle, dann die drei wichtigsten Punkte im Klartext

## Prüfliste

### Struktur

- [ ] Stern-Schema? Faktentabellen in der Mitte, Dimensionen außen
- [ ] Schneeflocken vorhanden — und wenn ja, mit Begründung?
- [ ] Beziehungen zwischen Dimensionen (statt über die Faktentabelle)? Fast immer ein Fehler
- [ ] Mehrere Faktentabellen: teilen sie sich die Dimensionen korrekt?
- [ ] Gibt es Tabellen, die niemand benutzt?

### Granularität

- [ ] Ist die Granularität je Faktentabelle **benannt** — eine Zeile ist genau was?
- [ ] Sind Fakten unterschiedlicher Granularität in einer Tabelle vermischt?
- [ ] Passt die Granularität zur feinsten benötigten Auswertung — nicht feiner, nicht gröber?

### Beziehungen

- [ ] Richtung und Kardinalität je Beziehung geprüft?
- [ ] Beidseitige Filterung nur dort, wo sie gebraucht wird und begründet ist?
- [ ] Aktive und inaktive Beziehungen dokumentiert?
- [ ] Mehrdeutige Pfade zwischen Tabellen aufgelöst?
- [ ] Schlüssel auf beiden Seiten mit gleichem Datentyp?

### Datumstabelle

- [ ] Eigene, durchgehende Datumstabelle vorhanden?
- [ ] Als Datumstabelle markiert? (Ohne das arbeitet Zeitintelligenz still falsch)
- [ ] Deckt sie den vollen benötigten Zeitraum ab, ohne Lücken?
- [ ] Geschäftsjahr, Perioden, Feiertage — soweit fachlich gebraucht?

### Spalten und Datentypen

- [ ] Datentypen so eng wie möglich?
- [ ] Textspalten mit sehr vielen verschiedenen Werten — nötig, oder Altlast?
- [ ] Technische Schlüssel ausgeblendet?
- [ ] Spalten, die kein Mensch je auswertet — entfernt?

### Kennzahlen

- [ ] Jede Kennzahl hat eine fachliche Definition
- [ ] Berechnete Spalten, die eigentlich Kennzahlen sein müssten?
- [ ] Verhalten in der Gesamtsumme je Kennzahl geprüft?
- [ ] Verwaiste Kennzahlen, die nirgends verwendet werden?

### Sicherheit

- [ ] Zeilenrechte im Modell hinterlegt oder bewusst nicht?
- [ ] Bricht eine beidseitige Filterung die Zeilenfilter auf?
- [ ] Ist geprüft, welche Rollen die Filter umgehen können?

### Benennung

- [ ] Konventionen durchgehalten?
- [ ] Namen fachlich verständlich für Menschen, die das Modell nicht gebaut haben?
- [ ] Deutsch/Englisch konsequent, nicht gemischt?

## Ausgabeformat

```
## Bewertung

| Bereich | Ergebnis | Kurz |
|---|---|---|
| Struktur | ok / Hinweis / Befund | ... |
| Granularität | ... | ... |
| Beziehungen | ... | ... |
| Datumstabelle | ... | ... |
| Kennzahlen | ... | ... |
| Sicherheit | ... | ... |
| Benennung | ... | ... |

## Befunde

### 1. [Titel] — schwer / mittel / leicht
**Was:** ...
**Wirkung:** [was im Bericht passiert oder passieren kann]
**Empfehlung:** ...
**Aufwand:** [klein / mittel / groß]

## Die drei wichtigsten Punkte
1. ...
```

## Haltung

Schwere zuerst, Kosmetik zuletzt. Ein falsch gerichteter Filter, der Zahlen verfälscht, wiegt schwerer
als zwanzig uneinheitlich benannte Spalten. Und wenn das Modell gut ist, gehört das auch gesagt — ein
Review, das um jeden Preis Befunde produziert, wird beim zweiten Mal nicht mehr gelesen.

## Hausergänzungen

> Eigene Modellierungsvorgaben, Pflichtdimensionen, Vorgaben zu Historisierung und Gültigkeitszeiträumen.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
