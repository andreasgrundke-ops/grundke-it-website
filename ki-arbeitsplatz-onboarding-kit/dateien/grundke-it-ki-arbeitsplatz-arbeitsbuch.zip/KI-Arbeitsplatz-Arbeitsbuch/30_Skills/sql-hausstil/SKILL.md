---
name: sql-hausstil
description: Einheitlicher Hausstil für T-SQL — Kopfzeilen, Versionierung, Formatierung, Benennung, typische Fallstricke. Nutzen, sobald SQL geschrieben, geprüft oder umgebaut wird (SELECT, Sichten, Prozeduren, Funktionen, Ladestrecken, Migrationen).
---

# SQL-Hausstil

Gilt für jedes SQL, das dauerhaft irgendwo liegt. Für Wegwerf-Abfragen im Analysefenster gilt nur der
Abschnitt „Fallstricke".

## Kopfzeile — Pflicht bei jedem Skript

```sql
/* ============================================================
   Titel:        [Was es tut]
   Objekt:       [Schema.Objektname]
   Version:      1.0.0
   Autor:        [Name]
   Datum:        JJJJ-MM-TT
   Zweck:        [Fachlich, ein bis zwei Sätze — nicht technisch]
   Abhängig von: [Tabellen, Sichten, Prozeduren]
   Änderungshistorie:
     v1.0.0  JJJJ-MM-TT  [Autor]  Erstfassung
   ============================================================ */
```

**Bei jeder Änderung:** Version hochzählen, Datum setzen, Zeile in der Änderungshistorie ergänzen.
Ohne Ausnahme — auch bei einer geänderten Zeile. Eine Prozedur ohne nachvollziehbare Historie ist in
einem geprüften Umfeld ein Befund.

## Formatierung

- Schlüsselwörter GROSS, Bezeichner wie in der Datenbank geschrieben
- Ein Feld je Zeile bei mehr als drei Feldern
- Komma **vorangestellt** — dann lässt sich jede Zeile einzeln auskommentieren
- Einrückung 4 Leerzeichen, keine Tabulatoren
- `JOIN`-Bedingungen immer in `ON`, nie in `WHERE`
- Jede Tabelle bekommt einen sprechenden Alias, nicht `a`, `b`, `c`

```sql
SELECT
     v.VertragId
   , v.Beginn
   , d.Bezeichnung AS Sparte
FROM        dbo.F_Vertrag AS v
INNER JOIN  dbo.D_Sparte  AS d  ON d.SparteId = v.SparteId
WHERE       v.Beginn >= @Von
      AND   v.Storniert = 0;
```

## Benennung

| Objekt | Muster |
|---|---|
| Faktentabelle | `F_<Fach>` |
| Dimension | `D_<Fach>` |
| Sicht | `V_<Zweck>` |
| Prozedur | `proc_<Bereich>_<Zweck>` |
| Funktion | `fn_<Zweck>` |
| Schlüssel | `<Entität>Id` |
| Zeitstempel | `ErstelltAm`, `GeaendertAm` |

Deutsch oder Englisch ist eine Hausentscheidung — aber **eine** Entscheidung, nicht beides gemischt.

## Was immer dazugehört

- **Kommentar an nicht offensichtlichen Stellen.** Was der Code tut, sieht man; warum er es tut, nicht.
  Fachliche Sonderregeln gehören kommentiert.
- **Mengenbasiert statt Zeile für Zeile.** Ein Cursor braucht eine Begründung im Kommentar.
- **Kein `SELECT *`** außerhalb von Ad-hoc-Abfragen.
- **Explizite Datentypen** bei Variablen und Parametern, inklusive Länge.
- **Transaktionen** um mehrteilige Schreiboperationen, mit Fehlerbehandlung.

## Fallstricke, die regelmäßig teuer werden

| Fallstrick | Woran man ihn erkennt |
|---|---|
| Funktion um eine Spalte im `WHERE` | Index wird nicht genutzt — `WHERE YEAR(Datum)=2026` statt Bereichsfilter |
| Implizite Typumwandlung | `nvarchar`-Spalte gegen Zahl verglichen — stiller Scan über alles |
| `NULL` in `NOT IN` | Ergebnis ist leer, ohne Fehlermeldung |
| Datumsbereiche mit `BETWEEN` | Der letzte Tag fehlt bei Zeitanteil — besser `>= @Von AND < @Bis` |
| Fehlende `ORDER BY` bei `TOP` | Ergebnis ist beliebig, aber sieht stabil aus |
| Aggregat über Verknüpfung mit Vervielfachung | Summen zu hoch, fällt oft erst im Fachbereich auf |
| `SET NOCOUNT OFF` in Prozeduren | unnötige Meldungen, irritiert aufrufende Anwendungen |

## Vor der Abgabe

- [ ] Läuft die Abfrage auf einer Testumgebung durch?
- [ ] Stimmt die Zeilenzahl mit einer unabhängigen Gegenrechnung überein?
- [ ] Ist der Ausführungsplan angesehen worden — gibt es einen unerwarteten Scan?
- [ ] Kopfzeile vollständig, Version stimmt?
- [ ] Keine hart eingebauten Verbindungsdaten, Pfade oder Passwörter?

## Wenn ich Code prüfe

Zuerst sagen, was das Skript fachlich tut — in eigenen Worten. Wenn das nicht gelingt, ist der Code
unklar, und das ist der erste Befund. Danach Fallstricke, dann Stil. Nie umgekehrt.

## Hausergänzungen

> Hier tragen sich die eigenen Regeln ein: abweichende Namenskonventionen, verbotene Muster, Vorgaben
> aus dem Datenbank-Betriebshandbuch, bekannte Eigenheiten der eigenen Umgebung.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.0*
