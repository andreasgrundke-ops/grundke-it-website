---
name: dokumentation
description: Technische und fachliche Dokumentation schreiben — Kennzahlen-Glossar, Datenmodell-Doku, Betriebsanleitungen, Übergabedokumente. Nutzen bei "dokumentiere das", "schreib eine Anleitung", "das muss übergabefähig sein".
---

# Dokumentation

## Erste Frage immer: für wen?

| Leser | Braucht | Braucht nicht |
|---|---|---|
| **Fachbereich** | Was bedeutet die Zahl, wie ist sie definiert, worauf ist zu achten | Technik |
| **Nachfolge im eigenen Fach** | Aufbau, Entscheidungen und ihre Gründe, Fallstricke | Grundlagenerklärungen |
| **Betrieb** | Was tun, wenn etwas nicht läuft; wen fragen | Fachlogik |
| **Prüfung / Revision** | Nachvollziehbarkeit, Kontrollen, wer hat was freigegeben | Umsetzungsdetails |

Ein Dokument für alle vier wird für keinen nützlich. Lieber vier kurze.

## Was fast immer fehlt

**Das Warum.** Der Aufbau lässt sich aus dem System ablesen. Warum es so aufgebaut ist, welche
Alternative verworfen wurde und weshalb — das weiß nur, wer dabei war. Genau das gehört dokumentiert,
alles andere ist nachrangig.

**Die Fallstricke.** Was schon einmal schiefgegangen ist, spart der Nachfolge Tage.

**Die Grenzen.** Was das System bewusst nicht abdeckt. Ohne diesen Abschnitt sucht jemand später einen
Fehler, der keiner ist.

## Kennzahlen-Glossar

Je Kennzahl:

| Feld | Inhalt |
|---|---|
| Name | wie im Bericht sichtbar |
| Fachliche Definition | ein bis zwei Sätze, ohne Formel, für den Fachbereich |
| Berechnungsgrundlage | welche Daten, welcher Zeitbezug |
| Abgrenzung | was ausdrücklich **nicht** enthalten ist |
| Verhalten in Summen | wie sie sich verdichtet |
| Bei fehlenden Daten | leer, null oder Strich — und warum |
| Verantwortlich | wer entscheidet über Änderungen |
| Geändert | Datum und Grund |

Die Zeile „Abgrenzung" beendet die meisten Diskussionen im Berichtswesen, bevor sie anfangen.

## Betriebsanleitung

- Was läuft wann, ausgelöst wodurch
- Woran erkennt man, dass es gelaufen ist
- Die drei häufigsten Störungen und was dann zu tun ist
- Wen anrufen, wenn das nicht reicht
- Was auf **keinen Fall** getan werden darf

Der letzte Punkt gehört nach oben, nicht ans Ende.

## Übergabedokument

1. Was ist das und wofür
2. Wo liegt was (Ordner, Systeme, Zugänge — Zugänge benennen, nicht enthalten)
3. Wie läuft der Betrieb
4. Was ist offen, was ist bewusst nicht gemacht
5. Bekannte Fallstricke
6. Ansprechpartner
7. Die drei Dinge, die ich anders machen würde

Punkt 7 ist der ehrlichste und nützlichste Abschnitt eines Übergabedokuments.

## Stil

- Aktiv, kurze Sätze, Gegenwartsform
- Tabellen wo es Struktur gibt, Fließtext wo es Zusammenhang gibt
- Kein Passiv-Nebel: „wird durchgeführt" — von wem?
- Abkürzungen bei der ersten Nennung ausschreiben
- Bilder nur, wenn sie etwas zeigen, das Text nicht kann
- Datum und Version im Kopf, sonst weiß niemand, ob es noch gilt

## Was gute Dokumentation ausmacht

Sie beantwortet die Fragen, die tatsächlich gestellt werden — nicht die, die sich elegant beantworten
lassen. Deshalb: bevor geschrieben wird, kurz überlegen, was jemand wissen will, der um 17 Uhr vor
einem Problem sitzt. Danach richtet sich der Aufbau.

## Hausergänzungen

> Eigene Dokumentvorlagen, Ablageorte, Freigabewege, Pflichtangaben aus dem internen Kontrollsystem.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
