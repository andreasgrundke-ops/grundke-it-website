---
name: dax-hausstil
description: Hausstil für DAX-Kennzahlen — Benennung, Formatierung, Kommentierung, Auswertungskontext, typische Fehler. Nutzen, sobald Kennzahlen (Measures), berechnete Spalten oder Tabellen in einem semantischen Modell geschrieben, erklärt oder geprüft werden.
---

# DAX-Hausstil

## Grundsatz: erst die Definition, dann die Formel

Eine Kennzahl ohne fachliche Definition ist keine Kennzahl, sondern eine Rechnung. Vor jeder Formel
steht ein Satz in Fachsprache:

> „Bestandsbeitrag: Summe der zum Stichtag gültigen Jahresbeiträge aller nicht stornierten Verträge,
> ohne Ratenzuschläge."

Steht das nicht, wird es zuerst geklärt — nicht geraten.

## Benennung

```
[<Bereich>] <Kennzahl> <Variante>
```

Beispiele: `Umsatz`, `Umsatz VJ`, `Umsatz VJ %`, `Umsatz kumuliert`, `Vertragsbestand Stichtag`

- Kennzahlen in Klarsprache, keine Abkürzungen außer eingeführten (`VJ`, `YTD`, `Ø`)
- Keine Datentyp- oder Technikkürzel im Namen
- Hilfskennzahlen, die niemand direkt benutzt, mit `_` beginnen und ausblenden
- Spalten und Kennzahlen nie gleich benennen — das erzeugt schwer auffindbare Verwechslungen

## Schreibweise

```dax
Umsatz VJ % =
// Veränderung zum Vorjahr in Prozent.
// Gibt BLANK zurück, wenn kein Vorjahreswert existiert — bewusst,
// damit im Bericht kein irreführendes 0 % erscheint.
VAR Aktuell = [Umsatz]
VAR Vorjahr = [Umsatz VJ]
RETURN
    DIVIDE ( Aktuell - Vorjahr, Vorjahr )
```

- **`VAR` statt verschachtelter Ausdrücke.** Lesbar, schneller, und man kann Zwischenschritte prüfen.
- **`DIVIDE` statt `/`** — fängt die Division durch Null ab.
- Kommentar über der Formel: **was** sie fachlich tut und **welche Sonderfälle** bewusst so behandelt
  sind.
- Funktionsnamen GROSS, Leerzeichen vor Klammern, ein Argument je Zeile bei langen Ausdrücken.

## Die drei Fragen zum Auswertungskontext

Bei jeder Kennzahl vor dem Schreiben beantworten:

1. **In welchem Kontext** wird sie angezeigt — je Zeile, je Monat, in der Gesamtsumme?
2. **Was soll in der Gesamtsumme stehen?** Die Summe der Zeilen oder eine eigene Berechnung? Bei
   Quoten, Durchschnitten und Beständen ist die Summe der Zeilen fast immer falsch.
3. **Was bei fehlenden Daten** — `BLANK`, Null oder Strich? Das ist eine fachliche Aussage, keine
   Formatierung.

Frage 2 ist die häufigste Fehlerquelle in Berichten überhaupt.

## Typische Fehler

| Fehler | Wirkung |
|---|---|
| Berechnete Spalte statt Kennzahl | Reagiert nicht auf Filter, Modell wird größer |
| `SUM` über eine bereits aggregierte Spalte | Doppelzählung |
| `FILTER` über eine ganze Tabelle statt `KEEPFILTERS` | langsam bei großen Modellen |
| Zeitintelligenz ohne markierte Datumstabelle | still falsche Ergebnisse |
| `CALCULATE` mit unklarer Filterüberschreibung | Ergebnis stimmt in der Zeile, nicht in der Summe |
| Division ohne `DIVIDE` | Fehler statt leerem Wert |
| Kennzahl ohne Format | Zahlen mit sechs Nachkommastellen im Bericht |

## Formatvorgaben

Aus dem Design-System übernehmen, nicht je Kennzahl neu erfinden:
Beträge, Stückzahlen, Quoten, Faktoren — je Art ein festes Format, Tausendertrennung und
Nachkommastellen einheitlich.

## Dokumentation

Jede fertige Kennzahl bekommt einen Eintrag im Glossar:

| Feld | Inhalt |
|---|---|
| Name | wie im Modell |
| Fachliche Definition | ein bis zwei Sätze, ohne Formel |
| Berechnungsgrundlage | welche Tabellen und Spalten |
| Sonderfälle | was bewusst ausgeschlossen oder anders behandelt wird |
| Verhalten in der Gesamtsumme | wie sie sich verdichtet |
| Geändert am | Datum und Grund |

## Wenn ich eine fremde Kennzahl erklären soll

1. Formel in eigenen Worten wiedergeben — fachlich, nicht technisch
2. Kontextverhalten beschreiben: Zeile, Zwischensumme, Gesamtsumme
3. Sonderfälle nennen: leere Werte, Division durch Null, Zeitbezug
4. Auf Fallstricke aus der Tabelle oben prüfen
5. Erst dann Verbesserungsvorschläge — und dabei sagen, was sich am Ergebnis ändert

## Hausergänzungen

> Eigene Namenskonventionen, Pflichtformate, verbotene Funktionen, Vorgaben aus dem Berichtsstandard.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
