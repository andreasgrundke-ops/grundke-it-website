---
name: testdaten-generator
description: Reproduzierbare synthetische Testdaten für analytische Datenmodelle erzeugen — als Skript, mit referentieller Integrität und realistischen Verteilungen. Nutzen, wenn Testdaten, Demodaten, Beispieldaten oder neutralisierte Datensätze gebraucht werden.
---

# Testdaten erzeugen

## Grundsatz: das Skript, nicht die Daten

Niemals Datenzeilen direkt ausschreiben. Immer ein **Skript**, das sie erzeugt.

Warum: ein Skript ist reproduzierbar (feste Zufallsbasis), versionierbar, prüfbar, beliebig skalierbar
und enthält seine eigene Dokumentation. Direkt ausgeschriebene Zeilen sind nichts davon.

## Die zwei Fehler, an denen es fast immer scheitert

**1. Zerrissene Beziehungen.** Jede Tabelle unabhängig erzeugt — Schäden zu Verträgen, die es nicht
gibt, Buchungen außerhalb der Laufzeit. Das Modell lädt, aber jede Auswertung ist Unsinn.
→ Lösung: **in Abhängigkeitsreihenfolge erzeugen**, Fremdschlüssel immer aus bereits erzeugten Sätzen
ziehen.

**2. Gleichverteilung.** Beträge zwischen 0 und 10.000 gleichverteilt sieht auf den ersten Blick
plausibel aus und macht jede Kennzahl unbrauchbar, weil die Ausreißer fehlen, um die es fachlich geht.
→ Lösung: **realistische Verteilungen**. Beträge und Schadenshöhen sind rechtsschief (log-normal),
Häufigkeiten sind Poisson-verteilt, Bestände haben Saisonalität und Abgangsquoten.

## Vorgehen

### 1 · Struktur aufnehmen

Tabellen, Spalten, Datentypen, Beziehungen, Granularität je Tabelle. Nur Struktur — keine Echtdaten.
Wenn schon Feld- oder Tabellennamen vertraulich sind, werden sie vorher verallgemeinert.

### 2 · Fachliche Regeln erfragen

Nicht raten. Die Fragen, die zählen:

- Welche Wertebereiche sind fachlich plausibel?
- Welche Kombinationen darf es **nicht** geben?
- Wie hoch sind typische Anteile — Abgänge, Ausfälle, Sonderfälle?
- Gibt es Saisonalität, Trends, Stichtagseffekte?
- Welche Sätze sollen bewusst Sonderfälle abbilden (leere Zuordnung, Grenzwert, Extremwert)?

Der letzte Punkt ist der wertvollste: Testdaten ohne Sonderfälle testen nichts.

### 3 · Reihenfolge festlegen

```
Kalender  →  Stammdimensionen  →  Zuordnungen  →  Bewegungsdaten  →  abgeleitete Daten
```

### 4 · Skript schreiben

- Feste Zufallsbasis am Anfang (`seed`), damit derselbe Lauf dieselben Daten liefert
- Alle Steuergrößen als Konstanten oben, nicht im Code verstreut
- Kopfzeile: Titel, Version, Datum, Zweck, welche Verteilungen und warum
- Ausgabe wahlweise CSV oder direkt als Einfüge-Anweisungen

### 5 · Plausibilitätsprüfungen ans Ende

Das Skript prüft sich selbst und bricht ab, wenn etwas nicht stimmt:

- keine Fremdschlüssel ohne passenden Satz
- keine Bewegungen außerhalb der Gültigkeitszeiträume
- keine negativen Werte, wo es keine geben darf
- Summen in einer fachlich sinnvollen Größenordnung
- jede Ausprägung, die eine Rolle abdecken soll, kommt mindestens einmal vor

Ohne diesen Abschnitt gilt das Skript als unfertig.

## Werkzeuge

| Werkzeug | Wofür |
|---|---|
| Python + `faker` | Feldwerte (Namen, Adressen, Datumsangaben), deutsche Lokalisierung |
| `numpy` | Verteilungen — log-normal, Poisson, Normalverteilung |
| `pandas` | Zusammenbau und Export |
| Fertige Mehrtabellen-Werkzeuge | erhalten Beziehungen automatisch — **vor Firmeneinsatz Lizenz prüfen**, einige stehen unter Nutzungsbeschränkungen |

Für die meisten Fälle reichen die ersten drei. Ein zusätzliches Werkzeug lohnt erst, wenn ein
bestehender Echtdatenbestand statistisch nachgebildet werden soll — und das ist datenschutzrechtlich
eine ganz eigene Frage.

## Beispielstruktur für ein Vertragsdatenmodell

```
D_Kalender     Tag, Monat, Quartal, Jahr, Geschäftsjahr
D_Sparte       SparteId, Bezeichnung
D_Vermittler   VermittlerId, Region, Eintritt, ggf. Austritt
D_Tarif        TarifId, SparteId, Beitragsstufe

F_Vertrag      VertragId, TarifId, VermittlerId, Beginn, Ende, Status
F_Beitrag      VertragId, Periode, Betrag        (nur innerhalb der Laufzeit)
F_Schaden      SchadenId, VertragId, Datum, Höhe (nur bei aktivem Vertrag)
F_Provision    VertragId, VermittlerId, Art, Betrag
```

Regeln, die das Skript einhalten muss: kein Schaden außerhalb der Laufzeit, kein Beitrag nach Ende,
Provision nur zu existierenden Verträgen, Storno erzeugt Rückforderung.

## Was am Ende dabei herauskommt

Skript, erzeugte Dateien, eine kurze Beschreibung der gewählten Verteilungen und Annahmen, und die
Prüfergebnisse. Die Beschreibung ist wichtig: Wer später eine seltsame Zahl sieht, muss erkennen können,
ob sie aus einer Annahme stammt oder aus einem Fehler.

## Hausergänzungen

> Eigenes Datenmodell, fachliche Wertebereiche, Pflicht-Sonderfälle, Vorgaben zur Datenmenge.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
