---
name: oberflaechen-design
description: Oberflächen, Dashboards und Berichtslayouts gestalten — Aufbau, Lesereihenfolge, Farben, Diagrammwahl, Barrierefreiheit, Zahlendarstellung. Nutzen bei Dashboard, Bericht, Formular, Seite, Mockup, "sieht unruhig aus", "findet niemand".
---

# Oberflächen und Berichte gestalten

## Erst die Frage, dann die Fläche

Vor jedem Layout drei Antworten:

1. **Wer schaut drauf** — und mit welcher Vorkenntnis?
2. **Welche Entscheidung** soll damit getroffen werden?
3. **Was ist die eine Zahl**, die zuerst gesehen werden muss?

Ein Dashboard ohne diese drei Antworten wird eine Sammlung von Kacheln, aus der jeder etwas anderes
herausliest.

## Aufbau

**Von oben links nach unten rechts, vom Groben zum Feinen.**

```
[ Kernaussage — 1 bis 3 Zahlen, groß ]

[ Verlauf ]              [ Verteilung ]

[ Tabelle mit Details, filterbar ]
```

- Wichtigstes oben links. Dort schaut jeder zuerst hin.
- Höchstens **5 bis 7 Elemente** je Ansicht. Mehr wird nicht gelesen, sondern überflogen.
- Details in eine zweite Ebene, nicht auf dieselbe Seite quetschen.
- Zusammengehöriges räumlich gruppieren, Abstand als Gliederungsmittel — nicht Linien.

## Diagrammwahl

| Frage | Darstellung |
|---|---|
| Wie ist der Stand? | Einzelzahl, groß |
| Wie hat es sich entwickelt? | Linie |
| Wer ist größer? | Balken, sortiert |
| Woraus setzt es sich zusammen? | gestapelter Balken |
| Wie hängen zwei Größen zusammen? | Punktwolke |
| Wie liegt Ist zu Plan? | Balken mit Zielmarke |
| Genaue Werte zum Nachlesen | Tabelle |

**Keine Torten für mehr als drei Werte.** Menschen können Winkel nicht vergleichen. Ein sortierter
Balken ist immer besser.

**Keine zweite Achse**, außer die Einheiten sind wirklich unvergleichbar — und dann mit deutlicher
Kennzeichnung.

**Nicht bei null abgeschnittene Balken.** Bei Linien ist ein anderer Nullpunkt vertretbar, bei Balken
verzerrt er die Aussage.

## Farbe

- **Farbe trägt Bedeutung, nicht Dekoration.** Jede Farbe im Bericht braucht eine feste Bedeutung.
- Höchstens fünf bis sechs unterscheidbare Kategorienfarben. Darüber hinaus fasst man zusammen.
- Ist gegen Plan: eine Zuordnung, überall gleich.
- Statusfarben aus dem Design-System, nicht je Bericht neu.
- Alles Nebensächliche in Grau — die Aufmerksamkeit gehört den Daten.

## Barrierefreiheit — nicht optional

- **Keine Information ausschließlich über Farbe.** Rot und grün sind für einen erheblichen Teil der
  Leser nicht unterscheidbar. Zusätzlich braucht es ein Vorzeichen, ein Zeichen oder eine Beschriftung.
- Ausreichender Kontrast zwischen Text und Hintergrund
- Schriftgröße nicht unter 12 Punkt in Berichten, die gelesen und nicht projiziert werden
- Bedienbarkeit auch ohne Maus

## Zahlen darstellen

- Nachkommastellen je Kennzahlenart festlegen und einhalten. Sechs Nachkommastellen sind kein Detail,
  sondern ein Fehler.
- Tausendertrennung immer
- Große Zahlen abkürzen (Tsd., Mio.) — aber einheitlich
- **Zahlen rechtsbündig**, Text linksbündig. Sonst kann man Spalten nicht vergleichen.
- Eine Schrift mit gleicher Zeichenbreite für Zahlenkolonnen
- Fehlende Werte einheitlich: Strich, nicht mal leer und mal null

## Beschriftung

- Jede Achse, jede Kachel, jedes Diagramm beschriftet
- Einheit dazu — „Umsatz" ist keine Einheit
- Stand des Datenbestands sichtbar: „Stand: 28.08.2026"
- Filter sichtbar machen. Ein Bericht, der gefiltert ist, ohne dass man es sieht, produziert falsche
  Entscheidungen.

## Prüfung vor der Abgabe

- [ ] Erkennt jemand ohne Erklärung in 10 Sekunden die Kernaussage?
- [ ] Ist klar, welcher Zeitraum und welcher Filter gilt?
- [ ] Funktioniert es in Graustufen — also ohne Farbunterscheidung?
- [ ] Stimmen die Formate mit dem Design-System überein?
- [ ] Gibt es ein Element, das niemand braucht? Dann weg damit.

Die letzte Frage ist die wirksamste. Fast jedes Dashboard wird durch Weglassen besser.

## Hausergänzungen

> Eigenes Design-System, Vorgaben aus dem Berichtsstandard, gesetzte Layoutraster.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.0*
