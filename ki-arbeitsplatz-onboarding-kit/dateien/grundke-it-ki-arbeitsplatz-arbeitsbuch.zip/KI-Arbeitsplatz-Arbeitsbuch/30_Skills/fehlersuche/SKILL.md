---
name: fehlersuche
description: Fehler methodisch eingrenzen statt raten — reproduzieren, isolieren, Ursache belegen, beheben, absichern. Nutzen bei Fehlermeldungen, falschen Zahlen, "geht nicht mehr", "gestern lief es noch", nicht nachvollziehbarem Verhalten.
---

# Fehlersuche

## Die Grundregel

**Erst verstehen, dann ändern.** Der häufigste Fehler bei der Fehlersuche ist, mehrere Dinge
gleichzeitig zu ändern und dann nicht zu wissen, welche geholfen hat — oder ob überhaupt eine geholfen
hat oder das Problem nur woanders hingerutscht ist.

## Fünf Schritte

### 1 · Reproduzieren

Was passiert genau, mit welchen Eingaben, in welcher Umgebung? Wenn es sich nicht reproduzieren lässt,
ist alles Weitere Raten.

Fragen: Was genau ist passiert, was war erwartet? Wann zuletzt korrekt? Was hat sich seitdem geändert
(Daten, Code, Umgebung, Rechte)? Betrifft es alle Fälle oder nur bestimmte?

Bei „gestern lief es noch": In neun von zehn Fällen hat sich etwas geändert — nur nicht dort, wo man
zuerst sucht. Häufig sind es Daten, nicht Code.

### 2 · Eingrenzen

Halbieren, bis der Bereich klein ist:

- Tritt der Fehler bei einem einzelnen Datensatz auf oder nur in der Menge?
- Tritt er in einer anderen Umgebung auch auf?
- Bei welchem Zwischenschritt stimmt das Ergebnis noch, bei welchem nicht mehr?

Bei Auswertungen: von der Kennzahl rückwärts durch Modell, Ladestrecke, Quelle. Der Fehler steckt fast
nie dort, wo er sichtbar wird.

### 3 · Ursache belegen

Eine Vermutung ist keine Ursache. Ein Beleg ist:

- eine Stelle, an der nachweislich der falsche Wert entsteht
- eine Bedingung, unter der der Fehler zuverlässig auftritt und ohne die nicht
- eine Erklärung, die **alle** beobachteten Symptome abdeckt, nicht nur das auffälligste

Deckt die Erklärung nicht alles ab, gibt es meistens zwei Fehler.

### 4 · Beheben

- **Eine Änderung auf einmal.** Nach jeder prüfen.
- Ursache beheben, nicht das Symptom kaschieren.
- Wenn nur das Symptom behandelt werden kann (etwa unter Zeitdruck): hinschreiben, dass es ein
  Notbehelf ist, und einen Punkt im Backlog anlegen. Ein unmarkierter Notbehelf wird zur Dauerlösung.

### 5 · Absichern

- Was verhindert, dass derselbe Fehler wiederkommt?
- Prüfung, Plausibilitätskontrolle oder Testfall ergänzen
- Fall in den Abschnitt „Bekannte Fallstricke" der CLAUDE.md eintragen

Dieser Schritt wird fast immer übersprungen und ist der einzige, der dauerhaft etwas spart.

## Bei falschen Zahlen in Auswertungen

Die Reihenfolge, die am schnellsten zum Ziel führt:

1. Ist der Wert wirklich falsch, oder ist die **fachliche Definition** eine andere als angenommen?
   (Überraschend oft ist das die Antwort.)
2. Stimmt der Wert in der Zeile, aber nicht in der Summe? → Kontextverhalten der Kennzahl
3. Stimmt er in keiner Zeile? → Modell, Beziehungen, Vervielfachung durch Verknüpfung
4. Stimmt er in bestimmten Zeiträumen nicht? → Zeitlogik, Datumstabelle, Gültigkeitszeiträume
5. Stimmt er für bestimmte Nutzer nicht? → Berechtigungen, Zeilenfilter
6. Erst dann in der Quelle suchen

## Ausgabeformat

```
## Symptom
[was beobachtet wurde, wörtlich]

## Reproduktion
[Schritte, unter denen es zuverlässig auftritt]

## Eingrenzung
[was geprüft und ausgeschlossen wurde — auch das gehört dokumentiert]

## Ursache
[belegt, mit Verweis auf die Stelle]

## Behebung
[konkret, eine Änderung]

## Absicherung
[was künftig davor schützt]
```

## Was nicht passiert

- Keine Änderung an Produktivsystemen ohne ausdrückliche Freigabe
- Keine „probier mal das"-Liste ohne Begründung
- Keine Behauptung, der Fehler sei behoben, ohne dass die Reproduktion sauber durchläuft

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.0*
