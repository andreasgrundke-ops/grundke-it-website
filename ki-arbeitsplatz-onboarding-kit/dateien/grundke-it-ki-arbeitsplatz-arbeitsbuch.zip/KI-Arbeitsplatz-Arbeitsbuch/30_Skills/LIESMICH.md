# Skills

Zwölf einsatzbereite Skills. Jeder liegt in einem eigenen Ordner mit einer `SKILL.md`.

## Hochladen

Im Unterordner **`_zum-hochladen/`** liegt jedes Skill bereits als fertige ZIP-Datei.

1. In Claude: Seitenleiste → **Customize** → Reiter **Skills**
2. **„+"** → **Upload a skill**
3. Die ZIP-Datei auswählen
4. Nach dem Hochladen prüfen, ob das Skill aktiviert ist

**Voraussetzung:** Code-Ausführung muss eingeschaltet sein (Einstellungen → Capabilities).
Ohne diesen Schalter tauchen Skills gar nicht erst auf.

Nicht alle auf einmal hochladen. Mit vier bis fünf anfangen, die zum aktuellen Thema passen — der Rest
kommt, wenn er gebraucht wird.

## Welche zuerst

| Reihenfolge | Skill | Warum |
|---|---|---|
| 1 | `sql-hausstil` | wirkt ab der ersten Abfrage |
| 2 | `dax-hausstil` | wirkt ab der ersten Kennzahl |
| 3 | `dokumentation` | macht Ergebnisse übergabefähig |
| 4 | `berechtigungs-audit` | der schnellste sichtbare Erfolg |
| 5 | `testdaten-generator` | Voraussetzung für alles Weitere ohne Echtdaten |
| dann | der Rest nach Bedarf | |

## Übersicht

| Skill | Zweck |
|---|---|
| `sql-hausstil` | T-SQL einheitlich schreiben, Kopfzeilen, Versionierung, Fallstricke |
| `dax-hausstil` | Kennzahlen benennen, formatieren, kommentieren, Kontextverhalten |
| `datenmodell-review` | Stern-Schema-Prüfliste, Modellfehler finden |
| `berechtigungs-audit` | Rollen- und Gruppenexporte prüfen, Widersprüche finden |
| `rls-konzept` | Zeilenrechte planen, dokumentieren, testbar machen |
| `testdaten-generator` | Skript für plausible erfundene Daten |
| `code-review` | Code strukturiert durchgehen |
| `fehlersuche` | Fehler methodisch eingrenzen |
| `dokumentation` | Glossar, Betriebsanleitung, Übergabe |
| `marketing-text` | Texte für Außenwirkung ohne Floskeln |
| `seo-und-ki-suche` | Auffindbarkeit klassisch und in KI-Antworten |
| `oberflaechen-design` | Dashboards und Berichtslayouts |

## Anpassen — der eigentliche Punkt

Die Skills sind **bewusst neutral gehalten**. Jeder endet mit einem Abschnitt „Hausergänzungen". Dort
gehören die eigenen Regeln hinein: Namenskonventionen, verbotene Muster, Freigabewege, was im eigenen
Haus als kritisch gilt.

Erst dadurch werden sie wertvoll. Ein Skill mit allgemeinen Regeln spart ein wenig Tipparbeit; ein Skill
mit den Hausregeln ersetzt die Erklärung, die man sonst jedem neuen Kollegen dreimal gibt.

**Vorgehen zum Anpassen:** `SKILL.md` bearbeiten, Ordner neu als ZIP packen, in Claude die alte Fassung
löschen und die neue hochladen. Aus dem Verzeichnis installierte Skills lassen sich nicht ändern —
eigene schon.

## Ein eigenes Skill schreiben

Aufbau:

```
mein-skill/
  SKILL.md          Pflicht
  referenzen/       optional: Nachschlagedateien
  vorlagen/         optional: Beispiele, Muster
```

Die `SKILL.md` beginnt mit einem Kopf:

```
---
name: mein-skill
description: Was es tut und wann es benutzt werden soll. Dieser Satz entscheidet,
  ob das Skill überhaupt geladen wird — er gehört sorgfältig formuliert.
---
```

Danach der Inhalt in normaler Markdown-Auszeichnung: Vorgehen, Regeln, Prüflisten, Ausgabeformat.

Die **Beschreibung** ist der wichtigste Teil. Sie ist das Einzige, was ständig gelesen wird; nach ihr
entscheidet sich, ob das Skill bei einer Anfrage überhaupt zum Zuge kommt. Deshalb: die Wörter
hineinschreiben, die man selbst benutzen würde, wenn man diese Aufgabe stellt.

## Sicherheit

Ein Skill ist ausführbarer Text. Aus fremder Quelle installierte Skills gehören geprüft wie jede andere
Software: Wer hat ihn geschrieben, was steht drin, welche Verbindungen baut er auf. Die Skills in diesem
Kit enthalten ausschließlich Text — keine Skripte, keine externen Aufrufe.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
