---
name: rls-konzept
description: Zeilenbasierte Berechtigungen (Row-Level Security) planen, dokumentieren und testbar machen — statisch gegen dynamisch, Bridge-Tabellen, Rollenmatrix, Pflichttestfälle. Nutzen, wenn Zeilenrechte entworfen, geändert oder geprüft werden.
---

# Zeilenrechte planen

## Reihenfolge — nicht verhandelbar

1. **Fachliche Regel** in Klarsprache aufschreiben
2. **Rollenmatrix** aufstellen: wer sieht welche Zeilen
3. **Umsetzungsweg** wählen (statisch, dynamisch, Bridge)
4. **Testfälle** definieren — vor dem Bauen
5. Erst dann bauen
6. Testfälle durchspielen, Ergebnis dokumentieren

Wer bei 5 anfängt, baut ein Konzept, das niemand mehr nachvollziehen kann — und in einem geprüften
Umfeld ist genau das der Befund, nicht die Technik.

## Die fachliche Regel

Ein Satz je Rolle, ohne Technik:

> „Ein Regionalleiter sieht alle Verträge der Regionen, für die er zuständig ist, einschließlich
> stornierter, aber ohne Personalverträge."

Was hier unklar bleibt, wird später als Fehler entdeckt. Deshalb: Sonderfälle jetzt klären.
Typische Auslassungen — stornierte Sätze, Sätze ohne Zuordnung, historische Zuständigkeiten,
Vertretungen, Vorgesetzte.

## Rollenmatrix

| Rolle | Sieht | Sieht nicht | Zuordnung über |
|---|---|---|---|
| Regionalleitung | Verträge der eigenen Regionen | Personalverträge | Verzeichnisgruppe je Region |
| Sachbearbeitung | Verträge des eigenen Teams | andere Teams | Bridge-Tabelle Person/Team |
| Gesamtleitung | alles | — | keine Filterrolle |
| Revision | alles, lesend | — | eigene Rolle |

## Umsetzungswege

| Weg | Wann | Vorteil | Nachteil |
|---|---|---|---|
| **Statisch** | wenige, stabile Rollen | einfach, sofort verständlich | je Ausprägung eine Rolle — wächst schnell |
| **Dynamisch über Anmeldenamen** | viele Nutzer, gleiche Regel | eine Rolle für alle | Format des Anmeldenamens muss stimmen |
| **Bridge-Tabelle** | komplexe Zuordnung, Mehrfachzuständigkeit | fachlich pflegbar, ohne Modelländerung | Tabelle muss gepflegt werden |

**Empfehlung für Häuser mit mehr als einer Handvoll Nutzern:** dynamisch mit Bridge-Tabelle. Die
Zuordnung „wer darf was" wird zu Fachdaten und damit im Fachbereich pflegbar, statt bei jeder
Änderung ein Modell anzufassen.

## Die vier Fallen

**1. Bearbeitungsrechte heben Filter auf.**
Zeilenfilter greifen typischerweise nur bei reinen Leserollen. Wer Bearbeitungs- oder Verwaltungsrechte
hat, sieht alles. Das ist die häufigste stille Lücke überhaupt — und der Grund, warum „kurz mal
Contributor geben" in einem regulierten Haus ein meldepflichtiger Vorgang werden kann.

**2. Das Format des Anmeldenamens.**
Bei externen Konten und Gästen liefert das Verzeichnis den Anmeldenamen je nach Konfiguration in
unterschiedlichen Formaten. Ein Filter, der ein Format erwartet, liefert beim anderen **leere
Ergebnisse statt eines Fehlers**. Das gehört im eigenen Haus einmal empirisch geprüft, nicht angenommen.

**3. Beidseitige Beziehungsfilterung.**
Sie kann Filter über Umwege aushebeln. Nach jeder Änderung an Beziehungen die Testfälle erneut
durchspielen.

**4. Sätze ohne Zuordnung.**
Zeilen, deren Zuordnungsschlüssel leer ist, fallen bei den meisten Filtern durch alle Rollen — sie sind
für niemanden sichtbar. Das ist fast nie gewollt und fällt erst auf, wenn Summen nicht stimmen.

## Testfälle — Pflicht

Je Rolle mindestens drei:

| # | Rolle | Testperson | Erwartet | Ergebnis |
|---|---|---|---|---|
| 1 | Regionalleitung Süd | test.sued | nur Region Süd, Summe = X | |
| 2 | Regionalleitung Süd | test.sued | keine Personalverträge sichtbar | |
| 3 | Regionalleitung Süd | test.sued | stornierte Verträge sichtbar | |
| 4 | Sachbearbeitung | test.sb | nur eigenes Team | |
| 5 | — | Satz ohne Zuordnung | von genau einer Rolle sichtbar | |

Dazu immer eine **Gegenprobe über alle Rollen**: Die Summe der rollenspezifischen Sichten muss die
Gesamtsumme ergeben, sonst fehlen oder doppeln sich Zeilen.

Für den Test gibt es Werkzeuge, die eine Abfrage unter fremder Identität ausführen — damit lässt sich
das automatisiert nachweisen statt durch Anmelden mit fremden Konten.

## Dokumentation

Für jedes Konzept:

- fachliche Regel je Rolle
- Rollenmatrix
- gewählter Umsetzungsweg mit Begründung
- Filterausdrücke mit Kommentar
- Testfälle mit Ergebnis und Datum
- bekannte Grenzen (etwa: Rollen mit Verwaltungsrechten sind ausgenommen)

Der letzte Punkt ist der wichtigste für die Revision: Was das Konzept **nicht** abdeckt, gehört
hingeschrieben, bevor jemand anders es findet.

## Hausergänzungen

> Eigene Rollennamenskonventionen, Vorgaben zur Rezertifizierung, Freigabewege für Rechteänderungen.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
