# KI-Arbeitsplatz — das Arbeitsbuch

Version 1.1.1 · Stand August 2026 · Grundke IT-Service

Ein vollständiger Satz Unterlagen, um von null auf arbeitsfähig zu kommen — vom Abo bis zur ersten
echten Aufgabe.

## Womit anfangen

**`Arbeitsbuch.html`** im Browser öffnen. Das ist der rote Faden: zwölf Phasen, jeder Punkt abhakbar,
der Stand bleibt in diesem Browser gespeichert. Alles Weitere in diesem Ordner sind Zuarbeiten dazu.

Die Datei läuft ohne Internet und ohne Installation und baut keine Verbindung nach außen auf. Sie lässt
sich ausdrucken oder als PDF sichern — das ist am Ende der Nachweis, was eingerichtet wurde.

Die jeweils aktuelle Fassung steht online unter
**grundke-it.de/ki-arbeitsplatz-onboarding-kit/** — dort ist auch der Fortschritt abhakbar.

## Was drin liegt

| Ordner | Inhalt |
|---|---|
| `Arbeitsbuch.html` | Der abhakbare Plan. Einstiegspunkt. |
| `00_Anleitungen/` | Langfassungen zu den Phasen — nachschlagen, wenn ein Punkt unklar ist |
| `10_Muster-MD/` | Textbausteine zum Kopieren: persönliche Anweisungen, CLAUDE.md in drei Ebenen, Status- und Backlog-Vorlagen |
| `20_Projektvorlagen/` | Zwei fertige Projekte — privat und beruflich — samt Ordnerstruktur |
| `30_Skills/` | Zwölf einsatzbereite Skills. Je Ordner eine `SKILL.md`, dazu `_zum-hochladen/` mit fertigen ZIPs. |
| `40_Konnektoren/` | Checkliste, was verbunden wird, warum und wer es freigegeben hat |

## Die drei Regeln, die alles andere tragen

1. **Erst der Rahmen, dann die Technik.** Phase 0 klärt, welche Daten überhaupt in dieses Konto dürfen.
   Wer das überspringt, baut ein Compliance-Problem statt eines Arbeitsplatzes.
2. **Ein privates Abo ist kein Firmenwerkzeug.** Pro und Max laufen unter Verbraucherbedingungen. Einen
   Auftragsverarbeitungsvertrag nach Art. 28 DSGVO gibt es erst ab dem Team-Plan. Für Methodik, Struktur
   und Fachwissen braucht es keine echten Personendaten — für alles andere braucht es einen Vertrag.
3. **Kontext schlägt Kniffe.** Wer einmal ordentlich aufschreibt, wer er ist, wie er arbeitet und was das
   Projekt ist, bekommt dauerhaft bessere Ergebnisse als jemand, der Prompt-Tricks sammelt.

## Die Skills anpassen

Jeder Skill endet mit einem Abschnitt **Hausergänzungen**. Dort gehören die eigenen Regeln hinein:
Namenskonventionen, verbotene Muster, Freigabewege, was im eigenen Haus als kritisch gilt. Erst dadurch
werden sie richtig wertvoll — vorher sparen sie nur Tipparbeit.

## Wenn etwas nicht stimmt

Anbieter und Funktionsumfang ändern sich schnell. Alles hier Beschriebene entspricht dem Stand
August 2026. Weicht eine Oberfläche ab, gilt die Oberfläche — nicht dieses Dokument. Solche Abweichungen
gehören zurückgemeldet, damit das Arbeitsbuch aktuell bleibt.

---

**Grundke IT-Service** · IT-Betreuung und KI-Anwendungen für kleine und mittlere Unternehmen
[grundke-it.de](https://grundke-it.de) · [Kontakt](https://grundke-it.de/kontakt/)

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
