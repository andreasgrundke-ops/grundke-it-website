# CLAUDE.md — Ebene 2: Projekt

Eine je Themenordner. Beantwortet: Was ist das hier, womit gebaut, wie ist der Stand, was kommt als
Nächstes. Wenn diese Datei stimmt, kann jede neue Sitzung sofort weiterarbeiten.

---

```markdown
# CLAUDE.md — [Projektname]

## Ziel (ein Satz)
[Was dieses Projekt leisten soll — für wen, wozu.]

## Fachlicher Hintergrund
[Was jemand wissen muss, der neu dazukommt: Begriffe, Kennzahlen, Besonderheiten
der Fachlichkeit. Zwei bis fünf Sätze, keine Abhandlung.]

## Technik
- [Datenbank / Werkzeuge / Formate]
- [Wo liegen Quellen, wo Ergebnisse]
- [Abweichungen vom Standard und deren Begründung]

## Regeln in diesem Projekt
- [Namenskonventionen]
- [Was auf keinen Fall angefasst wird]
- [Freigaben: was darf ohne Rückfrage geändert werden, was nicht]

## Datenlage
[Welche Daten liegen hier — erfunden, neutralisiert, nur Struktur? Was fehlt bewusst?]

## Stand
- Zuletzt: [Datum] — [was gemacht wurde]
- Offen: [Entscheidungen, die noch nicht getroffen sind — nicht eigenmächtig entscheiden]
- Nächster Schritt: [konkret, eine Zeile]

## Bausteine
| Kürzel | Baustein | Status |
|---|---|---|
| B1 | [Name] | [offen / in Arbeit / fertig] |
| B2 | [Name] | [offen / in Arbeit / fertig] |

## Verweise
STATUS.md · BACKLOG.md · [weitere Dokumente]
```

---

## So füllt man sie am schnellsten

Nicht tippen — abfragen lassen. Neue Sitzung im Projektordner öffnen und sagen:

> Wir legen die CLAUDE.md für dieses Projekt an. Frag mich der Reihe nach ab, was in die Vorlage gehört,
> eine Frage nach der anderen. Am Ende schreibst du die fertige Datei.

Das dauert fünf bis zehn Minuten, lässt sich diktieren, und das Ergebnis ist besser als jedes selbst
getippte Dokument, weil nichts vergessen wird.

## Pflege

Die Abschnitte **Stand** und **Bausteine** gehören am Ende jedes Arbeitsblocks aktualisiert. Alles
andere ändert sich selten. Eine CLAUDE.md, die drei Monate alt ist, ist schlimmer als keine — sie
führt zuverlässig in die falsche Richtung.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
