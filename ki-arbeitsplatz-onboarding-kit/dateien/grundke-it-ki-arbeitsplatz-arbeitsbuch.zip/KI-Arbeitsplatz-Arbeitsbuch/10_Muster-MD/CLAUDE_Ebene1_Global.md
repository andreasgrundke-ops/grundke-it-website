# CLAUDE.md — Ebene 1: Global (Wurzel)

Liegt im Wurzelordner der Arbeitsumgebung (`KI-Arbeit/00_Wurzel/CLAUDE.md`) und wird von Claude Code
in jeder Sitzung gelesen. Beantwortet: Wer arbeitet hier, nach welchen Regeln, und wo liegt was.

Platzhalter in eckigen Klammern ersetzen.

---

```markdown
# CLAUDE.md — Global

## Wer
[Vorname Nachname] · [Rolle] · [Fachbereich]. Zeitzone Europe/Berlin.

## Datenrahmen (gilt über allem)
In dieser Umgebung werden ausschließlich neutralisierte, erfundene oder öffentlich
unbedenkliche Daten verarbeitet. Keine personenbezogenen Echtdaten, keine Zugangsdaten,
keine vertraulichen Geschäftsunterlagen. Fällt dir etwas auf, das dagegen verstößt:
sag es, bevor du damit arbeitest.

## Arbeitsweise (immer)
- Erst planen, dann bauen. Bei größeren Änderungen zuerst den Plan zeigen.
- Nachfragen statt raten. Keine stillen Annahmen.
- Nichts vorauseilend erledigen, was nicht beauftragt ist.
- Bestehende Dateien nicht löschen, nur ergänzen. Löschen vorher rückfragen.
- Ehrlich bleiben: Risiken und Unsicherheiten benennen, nicht beschönigen.
- Deutsch, [Du/Sie], knapp, tabellarisch, kopierfähig. Keine Emojis.
- Echte Umlaute (ä ö ü ß).

## Handwerkliche Vorgaben
- Skripte immer vollständig und lauffähig, nie als Fragment.
- Kopfzeile in jedem Skript: Titel, Version, Autor, Datum, Zweck, Änderungshistorie.
- Version hochzählen und Änderungshistorie ergänzen bei jeder Änderung.
- Zugangsdaten und Verbindungszeichenfolgen ausschließlich in einer
  Konfigurationsdatei außerhalb des Codes, niemals fest eingebaut.
- Vor jeder Änderung an bestehendem Code: verstehen, was er tut, dann ändern.

## Struktur
Wurzel → 01_Privat / 02_Beruf → Thema. Je Thema genau eine CLAUDE.md.
Der Überblick über alle Themen steht in LANDKARTE.md.

## Gestaltung
Das Design-System liegt in 99_Vorlagen/design-system/. Farben, Schrift, Abstände und
Diagrammregeln kommen von dort — nicht neu erfinden.

## Verweise
LANDKARTE.md · 99_Vorlagen/ · je Thema STATUS.md
```

---

## Hinweise zur Pflege

- **Kurz halten.** Diese Datei wird jedes Mal gelesen. Alles, was nur ein Thema betrifft, gehört in
  die Projekt-CLAUDE.md, nicht hierher.
- **Nur Dauerhaftes.** Was sich nächste Woche ändert, gehört in `STATUS.md`.
- **Widersprüche auflösen.** Steht hier etwas anderes als in den kontoweiten Anweisungen, gewinnt in der
  Praxis das Speziellere — aber besser, es widerspricht sich gar nicht erst.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
