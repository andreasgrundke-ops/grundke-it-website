# Schema: Ein neues Projekt anlegen

Immer dieselben sieben Schritte, immer in dieser Reihenfolge. Wer die Reihenfolge ändert, baut
erfahrungsgemäß etwas, das später umgebaut werden muss.

---

## 1. Ziel in einem Satz

Wenn das nicht in einem Satz geht, ist es noch kein Projekt, sondern ein Themengebiet. Dann teilen.

> Prüffrage: Woran erkenne ich in drei Monaten, dass dieses Projekt erfolgreich war?

## 2. Datenrahmen festlegen

Welche Daten dürfen hier verarbeitet werden? Erfundene, neutralisierte, nur Strukturen? Diese Antwort
kommt in die erste Zeile der Projektanweisung — nicht ans Ende eines langen Dokuments.

## 3. Ordner und CLAUDE.md anlegen

Ordner erzeugen, `CLAUDE.md` aus der Ebene-2-Vorlage, `STATUS.md` und `BACKLOG.md` leer daneben.
Am schnellsten geht das, indem man Claude die Vorlage abfragen lässt statt selbst zu tippen.

## 4. Projekt in Claude anlegen

Projekt erstellen, Projektanweisungen setzen, `CLAUDE.md` und Design-System als Projektwissen
hochladen. Ab jetzt kennt jeder Chat in diesem Projekt den Rahmen.

## 5. In Bausteine zerlegen

Drei bis sieben Bausteine, jeder mit einer prüfbaren Fertig-Bedingung. Mehr als sieben heißt: das
Projekt ist zu groß geschnitten.

> Diesen Schritt kann Claude gut vorbereiten: Ziel und Rahmen geben, um einen Vorschlag zur Zerlegung
> bitten, dann selbst zusammenstreichen. Der Vorschlag ist selten perfekt, aber immer ein guter Anfang.

## 6. Ersten Baustein bauen — mit Plan

Planmodus, Plan lesen, freigeben, bauen lassen, Ergebnis prüfen. Nicht der zweite Baustein, bevor der
erste geprüft ist.

## 7. Dokumentieren und schließen

`STATUS.md` fortschreiben, `CLAUDE.md` beim Stand aktualisieren, Sitzung beenden. Fertig heißt
dokumentiert — sonst beginnt das nächste Mal mit Archäologie.

---

## Die häufigsten drei Fehler

**Alles in einer Unterhaltung.** Nach ein paar Stunden ist der Kontext voll und die frühen Absprachen
sind verdrängt. Ein Thema, eine Unterhaltung.

**Zu weiter Arbeitspfad.** Claude Code im Benutzerverzeichnis statt im Projektordner zu starten, ist
technisch möglich und praktisch eine schlechte Idee. Eng halten.

**Dokumentation auf später.** Sie wird nie geschrieben. Fünf Minuten am Ende, jedes Mal.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
