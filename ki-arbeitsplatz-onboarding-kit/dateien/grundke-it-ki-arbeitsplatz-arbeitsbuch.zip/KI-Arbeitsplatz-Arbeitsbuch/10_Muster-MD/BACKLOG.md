# BACKLOG.md — Vorlage

Alles, was auffällt, aber gerade nicht dran ist. Ohne diese Datei landet es in einem Chat und ist weg.

---

```markdown
# Backlog — [Projektname]

## Als Nächstes
- [ ] [Punkt] — [warum, ein Halbsatz]
- [ ] [Punkt]

## Wenn Zeit ist
- [ ] [Punkt]

## Ideen (unbewertet)
- [Punkt]

## Bewusst verworfen
- [Punkt] — verworfen am [Datum], weil [Grund]
```

---

## Warum der letzte Abschnitt wichtig ist

Verworfene Ideen kommen wieder. Steht der Grund dabei, kostet die zweite Runde eine Minute statt einer
Stunde. Ohne Begründung wird derselbe Vorschlag alle paar Monate neu diskutiert.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
