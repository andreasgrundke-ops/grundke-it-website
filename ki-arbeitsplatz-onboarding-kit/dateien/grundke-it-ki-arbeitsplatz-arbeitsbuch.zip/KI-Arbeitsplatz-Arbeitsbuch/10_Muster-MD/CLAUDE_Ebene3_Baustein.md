# Baustein-MD — Ebene 3

Für Teile, die groß genug sind, um eigenständig fertig zu werden: eine Ladestrecke, ein Datenmodell,
ein Berichtsblatt, ein Berechtigungskonzept. Dateiname: `<kuerzel>-<name>.md` im Themenordner.

Der Zweck ist nicht Dokumentation um ihrer selbst willen, sondern eine klare Antwort auf die Frage
„woran erkenne ich, dass dieser Teil fertig ist".

---

```markdown
# Baustein [B1.2] — [Name]

## Zweck
[Ein Satz: was dieser Baustein leistet.]

## Eingang / Ausgang
- Eingang: [was hineingeht — Tabellen, Dateien, Parameter]
- Ausgang: [was herauskommt]
- Fertig, wenn: [prüfbare Bedingung, keine Absichtserklärung]

## Prüfung
[Wie nachgewiesen wird, dass es stimmt. Konkrete Testfälle, erwartete Werte,
Gegenrechnungen. Ohne diesen Abschnitt ist der Baustein nicht fertig, sondern nur gebaut.]

## Abhängigkeiten
[Welche anderen Bausteine hängen daran. Ändert sich dieser hier, gehen die
abhängigen auf "prüfen".]

## Bekannte Grenzen
[Was bewusst nicht abgedeckt ist. Ehrlich — das spart später die Suche nach einem
Fehler, der keiner ist.]

## Status
[offen | in Arbeit | prüfen | fertig]

## Änderungshistorie
- v1.0.0 (JJJJ-MM-TT) — Erstfassung
```

---

## Warum der Prüfabschnitt der wichtigste ist

Bei Auswertungen und Kennzahlen fällt ein Fehler oft erst auf, wenn jemand im Fachbereich eine Zahl
nicht glaubt — Monate später. Wer je Baustein zwei bis drei prüfbare Testfälle festhält (etwa: „Summe
über alle Sparten muss der Gesamtsumme im Vorsystem entsprechen"), findet Fehler beim Bauen statt in
der Vorstandssitzung.

Diese Testfälle lassen sich hervorragend von Claude entwerfen: Baustein beschreiben, um eine Liste
prüfbarer Bedingungen bitten, davon die brauchbaren übernehmen.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.0*
