# STATUS.md — Vorlage

Kurzes Arbeitsprotokoll je Thema. Wird am Ende jedes Arbeitsblocks fortgeschrieben, oben neu.
Zweck: Eine neue Sitzung — ob nach zwei Tagen oder zwei Monaten — soll ohne Rückfragen weiterarbeiten
können.

---

```markdown
# Status — [Projektname]

## Jetzt gerade
[Zwei bis drei Sätze: woran zuletzt gearbeitet wurde und wo es steht.]

## Offene Entscheidungen
| Frage | Wer entscheidet | Bis wann |
|---|---|---|
| [z. B. Zeilenrechte über Gruppen oder über Bridge-Tabelle?] | [Name] | [Datum] |

## Nächste Schritte
1. [konkret]
2. [konkret]
3. [konkret]

## Blockiert durch
- [z. B. Freigabe der Administration steht aus — angefragt am TT.MM.]

## Verlauf
### JJJJ-MM-TT
- [was gemacht wurde]
- [was dabei gelernt wurde, wenn es für später zählt]

### JJJJ-MM-TT
- [...]
```

---

## Zwei Gewohnheiten, die den Unterschied machen

**Am Ende schreiben, nicht am Anfang.** Fünf Minuten am Ende eines Arbeitsblocks sparen zwanzig Minuten
Wiedereinstieg beim nächsten Mal.

**Auch das Scheitern notieren.** „Ansatz X ausprobiert, funktioniert nicht wegen Y" ist die wertvollste
Zeile in der ganzen Datei — sie verhindert, dass derselbe Weg in vier Wochen noch einmal gegangen wird.

---

*CI 2026.01 · Grundke IT-Service · [grundke-it.de](https://grundke-it.de) · Arbeitsbuch v1.1.1*
